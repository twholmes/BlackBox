---------------------------------------------------------------------------
-- Copyright (C) 2023 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: Data Model Customisations - Assets
-- Check Number: 2.5.1
-- Updated: 10/02/2024 10:10
---------------------------------------------------------------------------

--USE FNMSCompliance

------------------------------------------------------------------------------------------ 
-- Asset Data Model Customistaions
------------------------------------------------------------------------------------------

SELECT
  tp.[PropertyName]
  ,rc.CultureType
  ,(
     select 
      STUFF((
        select ',' + rtrim(replace(tx.AssetTypeID,',','')) 
        from [dbo].[AssetTypeProperty_MT] as tx 
        where tx.PropertyName = tp.PropertyName
        for xml path('')), 1,1,'') as 'AssetTypeIDs'
  ) as 'AssetTypeIDs'
  ,rc.ResourceValue
FROM [FNMSCompliance].[dbo].[AssetTypeProperty_MT] as tp
  JOIN [FNMSCompliance].[dbo].[ResourceStringCultureType] as rc on tp.PropertyName = rc.ResourceString
GROUP BY tp.[PropertyName], rc.CultureType ,rc.ResourceValue

GO
