##-------------------------------------------------------------------------
## Copyright (C) 2024 Crayon Australia
## This script runs an FNMS Health Check procedure
## Check Name: Check FNMS Installed Components
## Check Number: 2.3.1
## Updated: 11/02/2024 13:30
##-------------------------------------------------------------------------

param(
  [string]$LogsPathParam
  , [string]$ResultsPathParam  
)

## Get this script name and path
$Global:ScriptName = $MyInvocation.MyCommand.Name
$Global:ScriptPath = $MyInvocation.MyCommand.Path

################################################################################################
## GENERIC CODE - DONT EDIT THIS SECTION ##
Import-Module -Force (Join-Path  (Split-Path $script:MyInvocation.MyCommand.Path) 'CUA-functions.psm1')

############################################################
# Mainline

#Write-Log "LogsPathParam = $LogsPathParam"
#Write-Log "ResultsPathParam = $ResultsPathParam"
#Write-Log ""

## set txt results path if not supplied in params
$txtresultspath = $ResultsPathParam + ".txt"
if (-NOT ($ResultsPathParam))
{
  $txtresultspath = $ScriptPath + ".txt"
}
 
## remove any old check run results
if (Test-Path $txtresultspath) {
   Remove-Item $txtresultspath
} 
 
## report ScriptInfo
## *************************
## 231.SCRIPT INFO
## *************************
Write-ScriptInfo

## read FNMS registries for installed components
Write-Result "********************"
Write-Result "231.FNMS COMPONENTS"
Write-Result "********************"
Write-Result ""

$regKeyPath = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Flexera Software"
$regExists = Test-Path "HKLM:\SOFTWARE\WOW6432Node\Flexera Software"
if (!$regExists)
{
  ## registry key not found
  Write-Result ("Registry key {0} not found" -f $regKeyPath)
}
else
{
  ## check the featue installed reg values
  $FNMPVersion = Get-ItemProperty -Path "HKLM:\SOFTWARE\WOW6432Node\Flexera Software\FlexNet Manager Platform" | Select-Object -ExpandProperty FNMPVersion  
  Write-Result ("FNMP Version installed: {0}" -f $FNMPVersion)
  Write-Result ""

  $HasBatchProcessor = Get-ItemProperty -Path "HKLM:\SOFTWARE\WOW6432Node\Flexera Software\FlexNet Manager Platform\Features\CurrentVersion" | Select-Object -ExpandProperty BatchProcessor  
  Write-Result ("BatchProcessor feature installed: {0}" -f $HasBatchProcessor)

  $HasBatchServer = Get-ItemProperty -Path "HKLM:\SOFTWARE\WOW6432Node\Flexera Software\FlexNet Manager Platform\Features\CurrentVersion" | Select-Object -ExpandProperty BatchServer
  Write-Result ("BatchServer feature installed: {0}" -f $HasBatchServer)

  $HasInventoryServer = Get-ItemProperty -Path "HKLM:\SOFTWARE\WOW6432Node\Flexera Software\FlexNet Manager Platform\Features\CurrentVersion" | Select-Object -ExpandProperty InventoryServer
  Write-Result ("InventoryServer feature installed: {0}" -f $HasInventoryServer)

  $HasPresentationServer = Get-ItemProperty -Path "HKLM:\SOFTWARE\WOW6432Node\Flexera Software\FlexNet Manager Platform\Features\CurrentVersion" | Select-Object -ExpandProperty PresentationServer  
  Write-Result ("PresentationServer feature installed: {0}" -f $HasPresentationServer)
  
}
Write-Result ""

$mgsRegKeyPath = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\ManageSoft Corp\ManageSoft"
$mgsRegExists = Test-Path "HKLM:\SOFTWARE\WOW6432Node\ManageSoft Corp\ManageSoft"
if (!$mgsRegExists)
{
  ## registry key not found
  Write-Result ("Registry key {0} not found" -f $mgsRegKeyPath)
}
else
{
  ## check the featue installed reg values
  $ETDPVersion = Get-ItemProperty -Path "HKLM:\SOFTWARE\WOW6432Node\ManageSoft Corp\ManageSoft" | Select-Object -ExpandProperty ETDPVersion  
  Write-Result ("FNMP Beacon Version installed: {0}" -f $ETDPVersion)
  Write-Result ""

  $HasBatchProcessor = Get-ItemProperty -Path "HKLM:\SOFTWARE\WOW6432Node\ManageSoft Corp\ManageSoft\Beacon\CurrentVersion" | Select-Object -ExpandProperty BeaconMode  
  Write-Result ("Beacon installed and running in BeaconMode: {0}" -f $HasBatchProcessor)
  
}
Write-Result ""

