---------------------------------------------------------------------------
-- Copyright (C) 2024 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: FNMS Beacon List
-- Check Number: 2.3.3
-- Updated: 11/02/2024 20:00
---------------------------------------------------------------------------

--USE FNMSCompliance

------------------------------------------------------------------------------------------ 
-- FNMS Beacon List
------------------------------------------------------------------------------------------

SELECT 
  [BeaconID]
  ,[BeaconUID]
  ,[BeaconName]
  ,[BeaconDescription]
  ,[BeaconStatus]
  ,[BeaconLocation]
  ,[PrimaryParentUID]
  --,[BeaconPassword]
  --,[HTTPAccessData]
  --,[TenantID]
  --,[AvailablePackageID]
  ,[UpgradeModeID]
  ,[UpgradeStatusID]
  --,[UpgradeStatusTime]
  --,[LastKnownActivityTime]
  ,[ActivityStatusID]
  --,[PolicyDownloadedTime]
  ,[CurrentPolicyRevisionNo]
  ,[LastKnownPolicy]
  ,[Version]
  ,[WebServerStatusID]
  ,[ParentServerURL]
  ,[DownloadURL]
  ,[UploadURL]
FROM [dbo].[Beacon_MT]
  
GO
