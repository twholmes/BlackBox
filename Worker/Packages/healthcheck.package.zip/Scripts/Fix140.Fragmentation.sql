---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS Post Health Check (FIX) procedure
-- Fix Name: Fix Database Fragmentation
-- Fix Number: 1.40
-- Updated: 24/07/2023 10:15
---------------------------------------------------------------------------

--USE FNMSCompliance

ALTER INDEX ALL ON LicenseDefinitionUsageRight REORGANIZE;
ALTER INDEX ALL ON NewFileEvidence_S REORGANIZE;
ALTER INDEX ALL ON ARLStagingSoftwareTitle REORGANIZE;
ALTER INDEX ALL ON SoftwareTitleInstallerEvidence_S REORGANIZE;
ALTER INDEX ALL ON SoftwareSku REORGANIZE;
ALTER INDEX ALL ON SoftwareTitle_S REORGANIZE;
ALTER INDEX ALL ON SoftwareSku REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON InstalledInstallerEvidence_MT REORGANIZE;
ALTER INDEX ALL ON InstallerEvidence_S REORGANIZE;
ALTER INDEX ALL ON FileEvidencePath REORGANIZE;
ALTER INDEX ALL ON SoftwareTitle_S REORGANIZE;
ALTER INDEX ALL ON ComplianceHistory_MT REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON ARLStagingInstallerEvidence REORGANIZE;
ALTER INDEX ALL ON SoftwareTitleFileEvidence_S REORGANIZE;
ALTER INDEX ALL ON InstalledFileEvidence_MT REORGANIZE;
ALTER INDEX ALL ON InstalledFileEvidence_MT REORGANIZE;
ALTER INDEX ALL ON SoftwareSku REORGANIZE;
ALTER INDEX ALL ON SoftwareTitleInstallerEvidence_S REORGANIZE;
ALTER INDEX ALL ON FileEvidenceFile REORGANIZE;
ALTER INDEX ALL ON SoftwareSku REORGANIZE;
ALTER INDEX ALL ON SoftwareTitle_S REORGANIZE;
ALTER INDEX ALL ON SoftwareSku REORGANIZE;
ALTER INDEX ALL ON ImportedFileEvidence_MT REORGANIZE;
ALTER INDEX ALL ON SoftwareLicenseDefinition REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON ComplianceHistoryLimited_MT REORGANIZE;
ALTER INDEX ALL ON SoftwareLicenseDefinition REORGANIZE;
ALTER INDEX ALL ON ImportedFileEvidence_MT REORGANIZE;
ALTER INDEX ALL ON ARLDistinctStagingFileEvidence REORGANIZE;

GO
