---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: Remove Customisations
-- Check Number: 1.38
-- Updated: 24/07/2023 11:15
---------------------------------------------------------------------------

--USE FNMSCompliance
--GO

--SET NOCOUNT ON

--------------------------------------------------------------------------------------
-- User data model configuration (15)
--------------------------------------------------------------------------------------

PRINT 'Remove User custom properties from property dialogs'

-- Section Properties: Identification
--EXEC dbo.RemovePropertyFromWebUI @TargetTypeID = 15, @Name = 'CustomUserPropertyANUUserType', @DeleteFromDB = 1

--EXEC RebuildCustomPropertyViews
--GO

--------------------------------------------------------------------------------------
-- Purchases data model configuration (20)
--------------------------------------------------------------------------------------

PRINT 'Remove Purchases custom properties from property dialogs'

-- Section Properties: Details
--EXEC dbo.RemovePropertyFromWebUI @TargetTypeID = 20, @Name = 'CustomPurchasePropertyANUPONumber', @DeleteFromDB = 1
--EXEC dbo.RemovePropertyFromWebUI @TargetTypeID = 20, @Name = 'CustomPurchasePropertyANULicensedOn', @DeleteFromDB = 1

--EXEC RebuildCustomPropertyViews
--GO


--------------------------------------------------------------------------------------
-- Contracts data model configuration (10)
--------------------------------------------------------------------------------------

PRINT 'Remove Contracts custom properties and property dialogs'

-- Tab: General

-- Section Properties: Identification
--EXEC dbo.RemovePropertyFromWebUI @TargetTypeID = 10, @Name = 'CustomContractPropertyANULicensedOn', @DeleteFromDB = 1

-- Section Properties: Events
--EXEC dbo.RemovePropertyFromWebUI @TargetTypeID = 10, @Name = 'CustomContractPropertyANUExtensionDate', @DeleteFromDB = 1

--EXEC RebuildCustomPropertyViews
--GO


--------------------------------------------------------------------------------------
-- Software License data model configuration (12)
--------------------------------------------------------------------------------------

PRINT 'Remove License custom properties and property dialogs'

-- Tab: Identification

-- Section Properties: Identification
EXEC dbo.RemovePropertyFromWebUI @TargetTypeID = 12, @Name = 'BusinessOwner', @DeleteFromDB = 1
EXEC dbo.RemovePropertyFromWebUI @TargetTypeID = 12, @Name = 'UnderManagement', @DeleteFromDB = 1
GO
                                                                           
EXEC RebuildCustomPropertyViews
GO
