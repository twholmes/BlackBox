##-------------------------------------------------------------------------
## Copyright (C) 2024 Crayon Australia
## This script runs an FNMS Health Check procedure
## Check Name: Export Registry
## Check Number: 3.1.2
## Updated: 11/02/2024 13:30
##-------------------------------------------------------------------------

## Get this script name and path
$Global:ScriptName = $MyInvocation.MyCommand.Name
$Global:ScriptPath = $MyInvocation.MyCommand.Path

$Global:ResultsPath = $MyInvocation.MyCommand.Path + ".txt"

################################################################################################
## GENERIC CODE - DONT EDIT THIS SECTION ##
Import-Module -Force (Join-Path  (Split-Path $script:MyInvocation.MyCommand.Path) 'CUA-functions.psm1')

############################################################
# Mainline

## set txt results path if not supplied in params
$scriptdir = Split-Path -parent $MyInvocation.MyCommand.Definition
$parts = $ScriptName.split(".", 3)
$Global:ResultsPath = $scriptdir + "\" + $parts[0] + "." + $env:COMPUTERNAME + "." + $parts[1] + ".txt"
 
## remove any old check run results
if (Test-Path $ResultsPath) {
  Remove-Item $ResultsPath
} 
 
## report ScriptInfo
## *************************
## 312.SCRIPT INFO
## *************************
Write-ScriptInfo

## export the FNMS registries
Write-Result "********************"
Write-Result "312.FNMS REGISTRIES"
Write-Result "********************"
Write-Result ""

$regKeyPath = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Flexera Software"
$regExists = Test-Path "HKLM:\SOFTWARE\WOW6432Node\Flexera Software"
if (!$regExists)
{
  ## registry key not found
  Write-Result ("Registry key {0} not found" -f $regKeyPath)
}
else
{
  ## registry key exists so export it
  REG EXPORT $regKeyPath "fnms.reg" /y

  $reg = Get-Content -Path ".\fnms.reg"
  ## Alternate file-read: $reg = [System.IO.File]::ReadAllLines('.\fnms.reg')

  $reg.ForEach( { Write-Result $_ } )
  #del ".\fnms.reg"  
}
Write-Result ""

## export the Managesoft registries
Write-Result "********************"
Write-Result "312.MGS REGISTRIES"
Write-Result "********************"
Write-Result ""

$regKeyPath = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\ManageSoft Corp"
$regExists = Test-Path "HKLM:\SOFTWARE\WOW6432Node\ManageSoft Corp"
if (!$regExists)
{
  ## registry key not found
  Write-Result ("Registry key {0} not found" -f $regKeyPath)
}
else
{
  ## registry key exists so export it
  REG EXPORT $regKeyPath "mgs.reg" /y

  $reg = Get-Content -Path ".\mgs.reg"
  ## Alternate file-read: $reg = [System.IO.File]::ReadAllLines('.\mgs.reg')

  $reg.ForEach( { Write-Result $_ } )
  #del ".\mgs.reg"  
}
Write-Result ""
