##-------------------------------------------------------------------------
## Copyright (C) 2024 Crayon Australia
## This script runs an FNMS Health Check procedure
## Check Name: Event Log Errors
## Check Number: 5.1.4
## Updated: 12/02/2024 21:15
##-------------------------------------------------------------------------

## Get this script name and path
$Global:ScriptName = $MyInvocation.MyCommand.Name
$Global:ScriptPath = $MyInvocation.MyCommand.Path

$Global:ResultsPath = $MyInvocation.MyCommand.Path + ".txt"
###########################################################################
## GENERIC CODE - DONT EDIT THIS SECTION ##
Import-Module -Force (Join-Path  (Split-Path $script:MyInvocation.MyCommand.Path) 'CUA-functions.psm1')

############################################################
# Check folder for log files containing errors

function CheckFolderFilesForErrors([string]$filePath)
{ 
  if (!(Test-Path -Path $filePath))
  {
    Write-Result ("The directory {0} does not exist" -f $filePath)
  }
  else
  {
    cd $filePath
    try
    {
      ## The following code snippet gets all the files in $filePath that end in ".log".
      $PathArray = @()
      Get-ChildItem $filePath -Filter "*.log" |
      Where-Object { $_.Attributes -ne "Directory"} |
      ForEach-Object {
        If (Get-Content $_.FullName -Force -ErrorAction Stop | Select-String -Pattern "[Error]" -SimpleMatch) {
          $PathArray += $_.FullName
        }
      }
      Write-Result ("Files containing errors: {0}" -f $filePath)
      foreach ($filename in $PathArray)
      {
        Write-Result ("{0}" -f $filename)
      }
    }
    catch
    {
      Write-Result ("Error parsing files for errors: {0}" -f $filePath)    
    }
    Write-Result ""    
  }
}

############################################################
# Mainline

## set txt results path if not supplied in params
$scriptdir = Split-Path -parent $MyInvocation.MyCommand.Definition
$parts = $ScriptName.split(".", 3)
$Global:ResultsPath = $scriptdir + "\" + $parts[0] + "." + $env:COMPUTERNAME + "." + $parts[1] + ".txt"
 
## remove any old check run results
if (Test-Path $ResultsPath) {
  Remove-Item $ResultsPath
} 
  
## report ScriptInfo
## *************************
## 514.EVENT LOG ERRORS
## *************************
Write-ScriptInfo

## check windows event log
Write-Result "********************"
Write-Result "514.SYSTEM EVENT LOG"
Write-Result "********************"
Write-Result ""

## list system event log
Get-EventLog -LogName System -EntryType Error -Newest 50 | Out-File -FilePath Check514.EventLog.txt

## read system event log
$txt = Get-Content -Path Check514.EventLog.txt
$txt.ForEach( { Write-Result $_ } )

Write-Result ""


## check windows event log
Write-Result "*************************"
Write-Result "514.APPLICATION EVENT LOG"
Write-Result "*************************"
Write-Result ""

## list system event log
Get-EventLog -LogName Application -EntryType Error -Newest 50 | Out-File -FilePath Check514.EventLog.txt

## read system event log
$txt = Get-Content -Path Check514.EventLog.txt
$txt.ForEach( { Write-Result $_ } )

del Check514.EventLog.txt

Write-Result ""