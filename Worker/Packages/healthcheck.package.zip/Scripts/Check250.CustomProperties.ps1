##-------------------------------------------------------------------------
## Copyright (C) 2024 Crayon Australia
## This script runs an FNMS Health Check procedure
## Check Name: Check Data Model Customisations - Assets
## Check Number: 2.5.0
## Updated: 01/02/2024 20:55
##-------------------------------------------------------------------------

param(
  [string]$LogsPathParam
  , [string]$ResultsPathParam  
)

## Get this script name and path
$Global:ScriptName = $MyInvocation.MyCommand.Name
$Global:ScriptPath = $MyInvocation.MyCommand.Path

###########################################################################
## GENERIC CODE - DONT EDIT THIS SECTION ##
Import-Module -Force (Join-Path  (Split-Path $script:MyInvocation.MyCommand.Path) 'CUA-functions.psm1')

###########################################################################
# Mainline

#WriteLog "LogsPathParam = $LogsPathParam"
#WriteLog "ResultsPathParam = $ResultsPathParam"
#WriteLog ""

## set txt results path if not supplied in params
$txtresultspath = $ResultsPathParam + ".txt"
if (-NOT ($ResultsPathParam))
{
  $txtresultspath = $ScriptPath + ".txt"
}
 
## remove any old check run results
if (Test-Path $txtresultspath) {
   Remove-Item $txtresultspath
} 
  
## report ScriptInfo
## *************************
## 250.SCRIPT INFO
## *************************
Write-ScriptInfo

## database connecion parameters
$dbcs = ""
$dbserver = "localhost"
$database = "FNMSCompliance"

## get sql connection details frpm the registry
$regKeyPath = 'Registry::HKLM\SOFTWARE\WOW6432Node\ManageSoft Corp\ManageSoft\Reporter\CurrentVersion'
$regExists = (Get-Item $regKeyPath -EA Ignore).Property -contains "DatabaseConnectionString"
if ($regExists)
{
  $dbcs = Get-ItemPropertyValue -Path $regKeyPath -Name DatabaseConnectionString
  $params = $dbcs -split ";"
  $param1 = $params[1] -split "="
  $param2 = $params[1] -split "="  
  
  if ($param1[0] -eq "Server") { $dbserver = $param1[1] }
  #Write-Host $dbserver
  if ($param1[0] -eq "Database") { $database = $param2[1] }
  #Write-Host $database
}

## export custom properties
Write-Result "*****************************"
Write-Result "251.CUSTOM ASSET PROPERTIES"
Write-Result "*****************************"
Write-Result ""

## run the query to find custom asset properties
& SQLCMD.EXE -S $dbserver -d $database -i Check251.AssetCustomProperties.sql -o Check251.AssetCustomProperties.csv -s "," -W

## read custom asset property list
$csv = Get-Content -Path ".\Check251.AssetCustomProperties.csv"
$csv.ForEach( { Write-Result $_ } )

## export custom properties
Write-Result "******************************"
Write-Result "252.CUSTOM PURCHASE PROPERTIES"
Write-Result "******************************"
Write-Result ""

## run the query to find custom purchase properties
& SQLCMD.EXE -S $dbserver -d $database -i Check252.PurchasesCustomProperties.sql -o Check252.PurchasesCustomProperties.csv -s "," -W

## read custom purchase property list
$csv = Get-Content -Path ".\Check252.PurchasesCustomProperties.csv"
$csv.ForEach( { Write-Result $_ } )

## export custom properties
Write-Result "******************************"
Write-Result "253.CUSTOM LICENSE PROPERTIES"
Write-Result "******************************"
Write-Result ""

## run the query to find custom license properties
& SQLCMD.EXE -S $dbserver -d $database -i Check253.LicenseCustomProperties.sql -o Check253.LicenseCustomProperties.csv -s "," -W

## read custom license property list
$csv = Get-Content -Path ".\Check253.LicenseCustomProperties.csv"
$csv.ForEach( { Write-Result $_ } )

## export custom properties
Write-Result "******************************"
Write-Result "254.CUSTOM CONTRACT PROPERTIES"
Write-Result "******************************"
Write-Result ""

## run the query to find custom contract properties
& SQLCMD.EXE -S $dbserver -d $database -i Check254.ContractsCustomProperties.sql -o Check254.ContractsCustomProperties.csv -s "," -W

## read custom contract property list
$csv = Get-Content -Path ".\Check254.ContractsCustomProperties.csv"
$csv.ForEach( { Write-Result $_ } )

## export custom properties
Write-Result "*******************************"
Write-Result "255.CUSTOM S/W TITLE PROPERTIES"
Write-Result "*******************************"
Write-Result ""

## Run the query to find custom software title properties
& SQLCMD.EXE -S $dbserver -d $database -i Check255.SoftwareTitlesCustomProperties.sql -o Check255.SoftwareTitlesCustomProperties.csv -s "," -W

## read inventory connections list
$csv = Get-Content -Path ".\Check255.SoftwareTitlesCustomProperties.csv"
$csv.ForEach( { Write-Result $_ } )

Write-Result ""
