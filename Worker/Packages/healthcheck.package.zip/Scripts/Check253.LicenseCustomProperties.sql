---------------------------------------------------------------------------
-- Copyright (C) 2023 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: Data Model Customisations
-- Check Number: 2.5.3
-- Updated: 24/07/2023 12:15
---------------------------------------------------------------------------

--USE FNMSCompliance

------------------------------------------------------------------------------------------ 
--Software License Data Model Customistaions
------------------------------------------------------------------------------------------

SELECT
  tp.[PropertyName]
  ,rc.CultureType
  ,(
	   select 
	     STUFF((select ',' + rtrim(replace(tx.SoftwareLicenseTypeID,',','')) 
	   from [dbo].[SoftwareLicenseTypeProperty_MT] as tx 
	   where tx.PropertyName = tp.PropertyName
	   for xml path('')), 1,1,'') as 'SoftwareLicenseTypeIDs'
	) as 'SoftwareLicenseTypeIDs'
  ,rc.ResourceValue
FROM [dbo].[SoftwareLicenseTypeProperty_MT] as tp
  JOIN [dbo].[ResourceStringCultureType] as rc on tp.PropertyName = rc.ResourceString
GROUP BY tp.[PropertyName], rc.CultureType ,rc.ResourceValue

GO
