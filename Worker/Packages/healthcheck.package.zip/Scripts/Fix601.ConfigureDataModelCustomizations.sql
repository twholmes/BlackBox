---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: Configure Customisations
-- Check Number: 1.38
-- Updated: 24/07/2023 11:15
---------------------------------------------------------------------------

--USE FNMSCompliance
--GO

--SET NOCOUNT ON

--------------------------------------------------------------------------------------
-- Asset data model configuration (9)
--------------------------------------------------------------------------------------

PRINT 'Configuring Asset custom properties and property dialogs'

--EXEC RebuildCustomPropertyViews
--GO

--------------------------------------------------------------------------------------
-- Software License data model configuration (12)
--------------------------------------------------------------------------------------

PRINT 'Configuring License custom properties and property dialogs'

DECLARE @SequenceNumber int
SET @SequenceNumber = 0

-- Tab: Crayon
SET @SequenceNumber = @SequenceNumber + 1

EXEC dbo.AddTabToWebUIPropertiesPage
	  @TargetTypeID = 12 -- License
	, @Name = 'CustomTabLicenseCrayon'
	, @DisplayNameInPage = 'Crayon'
	, @UIInsertTypeID = 2 -- After
	, @ExcludeTargetSubTypeIDs = ''
	, @SequenceNumber = @SequenceNumber
	, @RelativeTabName = 'Tab_Ownership'

-- Tab Crayon: Management section
SET @SequenceNumber = @SequenceNumber + 1

EXEC dbo.AddSectionToWebUIPropertiesPage
	  @TargetTypeID = 12 -- License
	, @Name = 'CustomSectionLicenseCrayonManagement'
	, @DisplayNameInPage = 'Management'
	, @UIInsertTypeID = 3 -- Start of
	, @ExcludeTargetSubTypeIDs = ''
	, @SequenceNumber = @SequenceNumber
	, @RelativePositionTo = 'CustomTabLicenseCrayon'
	, @TabName = 'CustomTabLicenseCrayon'

-- Section Properties: Identification
SET @SequenceNumber = @SequenceNumber + 1

EXEC [AddPropertyToWebUIPropertiesPage]
  @TargetTypeID = 12,  /* license */
  @ExcludeTargetSubTypeIDs='',
  @Name = 'CustomLicensePropertyBusinessOwner',
  @DisplayNameInPage = 'Business Owner',
  @DisplayNameInReport ='Business Owner',
  @UIInsertTypeID = 2, -- After
	@UIFieldTypeID = 5, -- Text area
  @RelativePositionTo = 'CustomSectionLicenseCrayonManagement',
  @SequenceNumber = @SequenceNumber,
	@ReadOnly = 0,
  @Width = 1

SET @SequenceNumber = @SequenceNumber + 1

EXEC [AddPropertyToWebUIPropertiesPage]
  @TargetTypeID = 12,  /* license */
  @ExcludeTargetSubTypeIDs='',
  @Name = 'CustomLicensePropertyUnderManagement',
  @DisplayNameInPage = 'Under Management',
  @DisplayNameInReport ='Under Management',
  @UIInsertTypeID = 2, -- After
	@UIFieldTypeID = 9, -- Check box
  @RelativePositionTo = 'CustomLicensePropertyBusinessOwner',
  @SequenceNumber = @SequenceNumber,
	@ReadOnly = 0,
  @Width = 1

SET @SequenceNumber = @SequenceNumber + 1

EXEC RebuildCustomPropertyViews
GO
