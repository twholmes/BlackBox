---------------------------------------------------------------------------
-- Copyright (C) 2024 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: Inventory Connections
-- Check Number: 3.1.4
-- Updated: 11/02/2024 13:25
---------------------------------------------------------------------------

--USE FNMSCompliance

------------------------------------------------------------------------------------------ 
-- Agent Deployment Coverage
------------------------------------------------------------------------------------------

SELECT
  cc.[ComplianceConnectionID]
  ,cc.[ConnectionTypeID]
  ,cc.[ConnectionName]
  --,cc.[ConnectionNameDisplayName]
  --,cc.[UseFnmpDbServerAsSource]
  ,cc.[Server]
   --,cc.[UseWindowsAuth]
  ,cc.[Username]
   --,cc.[Password]
  ,cc.[DatabaseName]
  ,cc.[ConnectionString]
  ,cc.[LastImportDate]
  ,DATEDIFF(MINUTE, cc.[LastImportStarted], cc.[LastImportEnded]) AS [RunTime (min)]
  ,cc.[SourceType]
  --,cc.[SourceTypeDisplayName]
  --,cc.[Signature]
  ,cc.[PrimaryConnection]
  --,cc.[TestConnection]
  ,cc.[Enabled]
  --,cc.[GroupName]
  --,cc.[ExpiryPeriod]
  --,cc.[PerformStaleInventoryCheck]
  ,[IsRemote]
  --,cc.[ConnectionExID]
  --,cc.[BeaconUID]
FROM [dbo].[ComplianceConnection] AS cc


GO
