##-------------------------------------------------------------------------
## Copyright (C) 2024 Crayon Australia
## This script runs an FNMS Health Check procedure
## Check Name: Check Beacon List
## Check Number: 2.3.3
## Updated: 11/02/2024 20:00
##-------------------------------------------------------------------------

param(
  [string]$LogsPathParam
  , [string]$ResultsPathParam  
)

## Get this script name and path
$Global:ScriptName = $MyInvocation.MyCommand.Name
$Global:ScriptPath = $MyInvocation.MyCommand.Path

###########################################################################
## GENERIC CODE - DONT EDIT THIS SECTION ##
Import-Module -Force (Join-Path  (Split-Path $script:MyInvocation.MyCommand.Path) 'CUA-functions.psm1')

###########################################################################
# Mainline

#WriteLog "LogsPathParam = $LogsPathParam"
#WriteLog "ResultsPathParam = $ResultsPathParam"
#WriteLog ""

## set txt results path if not supplied in params
$txtresultspath = $ResultsPathParam + ".txt"
if (-NOT ($ResultsPathParam))
{
  $txtresultspath = $ScriptPath + ".txt"
}
 
## remove any old check run results
if (Test-Path $txtresultspath) {
   Remove-Item $txtresultspath
} 
  
## report ScriptInfo
## *************************
## 233.BEACON LIST
## *************************
Write-ScriptInfo

## database connecion parameters
$dbcs = ""
$dbserver = "localhost"
$database = "FNMSCompliance"

## get sql connection details frpm the registry
$regKeyPath = 'Registry::HKLM\SOFTWARE\WOW6432Node\ManageSoft Corp\ManageSoft\Reporter\CurrentVersion'
$regExists = (Get-Item $regKeyPath -EA Ignore).Property -contains "DatabaseConnectionString"
if ($regExists)
{
  $dbcs = Get-ItemPropertyValue -Path $regKeyPath -Name DatabaseConnectionString
  $params = $dbcs -split ";"
  $param1 = $params[1] -split "="
  $param2 = $params[1] -split "="  
  
  if ($param1[0] -eq "Server") { $dbserver = $param1[1] }
  #Write-Host $dbserver
  if ($param1[0] -eq "Database") { $database = $param2[1] }
  #Write-Host $database
}

## export custom properties
Write-Result "*****************************"
Write-Result "233.BEACON LIST"
Write-Result "*****************************"
Write-Result ""

## run the query to find compliance settings data
& SQLCMD.EXE -S $dbserver -d $database -i Check233.BeaconList.sql -o Check233.BeaconList.csv -s "," -W

## read custom asset property list
$csv = Get-Content -Path ".\Check233.BeaconList.csv"
$csv.ForEach( { Write-Result $_ } )

Write-Result ""
