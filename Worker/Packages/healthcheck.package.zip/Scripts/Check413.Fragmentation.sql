---------------------------------------------------------------------------
-- Copyright (C) 2024 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: Database Fragmentation
-- Check Number: 4.1.3
-- Updated: 12/02/2024 19:35
---------------------------------------------------------------------------

--USE FNMSCompliance

SELECT 
  OBJECT_NAME(i.object_id) AS TableName
  ,i.name AS IndexName
  ,s.index_type_desc
  ,s.avg_fragmentation_in_percent
  ,s.page_count
  ,s.fragment_count
  ,s.avg_fragment_size_in_pages
FROM sys.dm_db_index_physical_stats(DB_ID(),NULL,NULL,NULL,NULL) s
  JOIN sys.indexes I ON i.object_id = s.object_id AND i.index_id = s.index_id
WHERE	s.avg_fragmentation_in_percent > 30 AND s.page_count > 2500
ORDER BY s.avg_fragmentation_in_percent DESC

GO
