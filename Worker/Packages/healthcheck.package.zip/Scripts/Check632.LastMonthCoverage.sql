---------------------------------------------------------------------------
-- Copyright (C) 2024 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: Inventory Age
-- Check Number: 6.3.2
-- Updated: 12/02/2024 22:15
---------------------------------------------------------------------------

--USE FNMSCompliance

------------------------------------------------------------------------------------------ 
-- Last Month's Active Inventory Coverage
------------------------------------------------------------------------------------------

SELECT 
  100.0 * SUM
    (
      CASE WHEN c.InventoryDate >= DATEADD(m, -1, GETDATE()) THEN 1.0 
      ELSE 0.0 
      END
    ) / COUNT(c.ComplianceComputerID) AS PctComputersWithCurrentInventory
FROM dbo.ComplianceComputer c
WHERE c.ComplianceComputerStatusID = 1 /* active */

GO
