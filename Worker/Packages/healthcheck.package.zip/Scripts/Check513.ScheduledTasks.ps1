##-------------------------------------------------------------------------
## Copyright (C) 2024 Crayon Australia
## This script runs an FNMS Health Check procedure
## Check Name: Scheduled Tasks
## Check Number: 5.1.3
## Updated: 12/02/2024 21:15
##-------------------------------------------------------------------------

## Get this script name and path
$Global:ScriptName = $MyInvocation.MyCommand.Name
$Global:ScriptPath = $MyInvocation.MyCommand.Path

$Global:ResultsPath = $MyInvocation.MyCommand.Path + ".txt"

################################################################################################
## GENERIC CODE - DONT EDIT THIS SECTION ##
Import-Module -Force (Join-Path  (Split-Path $script:MyInvocation.MyCommand.Path) 'CUA-functions.psm1')

############################################################
# Check folder for log files containing errors

function CheckFolderFilesForErrors([string]$filePath)
{ 
  if (!(Test-Path -Path $filePath))
  {
    Write-Result ("The directory {0} does not exist" -f $filePath)
  }
  else
  {
    cd $filePath
    try
    {
      ## The following code snippet gets all the files in $filePath that end in ".log".
      $PathArray = @()
      Get-ChildItem $filePath -Filter "*.log" |
      Where-Object { $_.Attributes -ne "Directory"} |
      ForEach-Object {
        If (Get-Content $_.FullName -Force -ErrorAction Stop | Select-String -Pattern "[Error]" -SimpleMatch) {
          $PathArray += $_.FullName
        }
      }
      Write-Result ("Files containing errors: {0}" -f $filePath)
      foreach ($filename in $PathArray)
      {
        Write-Result ("{0}" -f $filename)
      }
    }
    catch
    {
      Write-Result ("Error parsing files for errors: {0}" -f $filePath)    
    }
    Write-Result ""    
  }
}

############################################################
# Mainline

## set txt results path if not supplied in params
$scriptdir = Split-Path -parent $MyInvocation.MyCommand.Definition
$parts = $ScriptName.split(".", 3)
$Global:ResultsPath = $scriptdir + "\" + $parts[0] + "." + $env:COMPUTERNAME + "." + $parts[1] + ".txt"
 
## remove any old check run results
if (Test-Path $ResultsPath) {
  Remove-Item $ResultsPath
} 
  
## report ScriptInfo
## *************************
## 513.SCHEDULES TASKS
## *************************
Write-ScriptInfo

## check scheduled tasks
Write-Result "********************"
Write-Result "513.SCHEDULED TASKS"
Write-Result "********************"
Write-Result ""

## read task list
Get-ScheduledTask -TaskPath "\" | Out-File -FilePath Check513.ScheduledTasks.txt
$txt = Get-Content -Path Check513.ScheduledTasks.txt
$txt.ForEach( { Write-Result $_ } )
del Check513.ScheduledTasks.txt

Get-ScheduledTask -TaskPath "\" | Export-ScheduledTask | Out-File -FilePath Check513.ScheduledTasks.xml

Write-Result ""
