---------------------------------------------------------------------------
-- Copyright (C) 2024 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: FNMS Compliance Settings
-- Check Number: 2.3.2
-- Updated: 11/02/2024 20:00
---------------------------------------------------------------------------

--USE FNMSCompliance

------------------------------------------------------------------------------------------ 
-- FNMS Compliance Settings
------------------------------------------------------------------------------------------

SELECT 
  [ComplianceSettingID]
  ,[SettingName]
  ,[SettingValue]
FROM [dbo].[ComplianceSetting]

GO
