##-------------------------------------------------------------------------
## Copyright (C) 2024 Crayon Australia
## This script runs an FNMS Health Check procedure
## Check Name: Inventory Age and Coverage
## Check Number: 6.30
## Updated: 12/02/2024 22:00
##-------------------------------------------------------------------------

param(
  [string]$LogsPathParam
  , [string]$ResultsPathParam  
)

## Get this script name and path
$Global:ScriptName = $MyInvocation.MyCommand.Name
$Global:ScriptPath = $MyInvocation.MyCommand.Path

###########################################################################
## GENERIC CODE - DONT EDIT THIS SECTION ##
Import-Module -Force (Join-Path  (Split-Path $script:MyInvocation.MyCommand.Path) 'CUA-functions.psm1')

###########################################################################
# Mainline

## set txt results path if not supplied in params
$txtresultspath = $ResultsPathParam + ".txt"
if (-NOT ($ResultsPathParam))
{
  $txtresultspath = $ScriptPath + ".txt"
}
 
## remove any old check run results
if (Test-Path $txtresultspath) {
   Remove-Item $txtresultspath
} 
  
## report ScriptInfo
## *************************
## 630.SCRIPT INFO
## *************************
Write-ScriptInfo

## database connecion parameters
$dbcs = ""
$dbserver = "localhost"
$database = "FNMSCompliance"

## get sql connection details frpm the registry
$regKeyPath = 'Registry::HKLM\SOFTWARE\WOW6432Node\ManageSoft Corp\ManageSoft\Reporter\CurrentVersion'
$regExists = (Get-Item $regKeyPath -EA Ignore).Property -contains "DatabaseConnectionString"
if ($regExists)
{
  $dbcs = Get-ItemPropertyValue -Path $regKeyPath -Name DatabaseConnectionString
  $params = $dbcs -split ";"
  $param1 = $params[1] -split "="
  $param2 = $params[1] -split "="  
  
  if ($param1[0] -eq "Server") { $dbserver = $param1[1] }
  #Write-Host $dbserver
  if ($param1[0] -eq "Database") { $database = $param2[1] }
  #Write-Host $database
}

## export coverage data
Write-Result "*****************************"
Write-Result "631.INVENTORY AGES"
Write-Result "*****************************"
Write-Result ""

## run the query to find the Inventory Age Profile
& SQLCMD.EXE -S $dbserver -d $database -i Check631.InventoryAgeProfile.sql -o Check631.InventoryAgeProfile.csv -s "," -W

## read the inventory age profile list
$csv = Get-Content -Path ".\Check631.InventoryAgeProfile.csv"
$csv.ForEach( { Write-Result $_ } )

## export coverage data
Write-Result "******************************"
Write-Result "632.INVENTORY COVERAGE"
Write-Result "******************************"
Write-Result ""

## run the query to find Active Inventory Coverage for the last month
& SQLCMD.EXE -S $dbserver -d $database -i Check632.LastMonthCoverage.sql -o Check632.LastMonthCoverage.csv -s "," -W

## read inventory coverage list
$csv = Get-Content -Path ".\Check632.LastMonthCoverage.csv"
$csv.ForEach( { Write-Result $_ } )

## export coverage data
Write-Result "******************************"
Write-Result "633.AGENT COVERAGE"
Write-Result "******************************"
Write-Result ""

## run the query to find Agent Coverage
& SQLCMD.EXE -S $dbserver -d FNMSInventory -i Check633.AgentCoverage.sql -o Check633.AgentCoverage.csv -s "," -W

## read agent coverage list
$csv = Get-Content -Path ".\Check633.AgentCoverage.csv"
$csv.ForEach( { Write-Result $_ } )

Write-Result ""
