---------------------------------------------------------------------------
-- Copyright (C) 2024 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: PURL Version
-- Check Number: 2.6.1
-- Updated: 04/02/2024 20:55
---------------------------------------------------------------------------

--USE FNMSCompliance

------------------------------------------------------------------------------------------ 
-- PURL Version
------------------------------------------------------------------------------------------

DECLARE @Version int
DECLARE @UpdateDate DateTime

SET @Version = (SELECT TOP (1) [ARLVersion] FROM [dbo].[ARLStatusWidgetModel])
SET @UpdateDate = (SELECT TOP (1) [UpdatedAt] FROM [dbo].[ARLStatusWidgetModel])

PRINT 'ARL Version = ' + convert(nvarchar(5), @Version)
PRINT 'ARL Version Updated = ' + convert(nvarchar(20), @UpdateDate)

SET @Version = (SELECT TOP (1) [Version] FROM [dbo].[PURLStatusWidgetModel])
SET @UpdateDate = (SELECT TOP (1) [UpdateDate] FROM [dbo].[PURLStatusWidgetModel])

PRINT 'PURL Version = ' + convert(nvarchar(5), @Version)
PRINT 'PURL Version Updated = ' + convert(nvarchar(20), @UpdateDate)

GO
