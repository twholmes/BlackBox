##-------------------------------------------------------------------------
## Copyright (C) 2024 Crayon Australia
## This script runs an FNMS Health Check procedure
## Check Name: Check FNMS User LOgins
## Check Number: 2.6.2
## Updated: 11/02/2024 13:30
##-------------------------------------------------------------------------

param(
  [string]$LogsPathParam
  , [string]$ResultsPathParam  
)

## Get this script name and path
$Global:ScriptName = $MyInvocation.MyCommand.Name
$Global:ScriptPath = $MyInvocation.MyCommand.Path

################################################################################################
## GENERIC CODE - DONT EDIT THIS SECTION ##
Import-Module -Force (Join-Path  (Split-Path $script:MyInvocation.MyCommand.Path) 'CUA-functions.psm1')

############################################################
# Set the name of the log file to write logging to

function SearchLogFiles([string]$logFilePath, [string]$resultsFilePath)
{
  cd $logFilePath

  Get-ChildItem u_ex*.log |
  Where { ((Get-Date) - $_.LastWriteTime).Days -le 30 } |
  %{ $_.Name } | % {
  Import-Csv $_ -Delimiter " " -Header ("a", "b", "c", "d", "e", "f", "g", "h", "user") |
  Where { $_.a -notLike "#*" -and $_.user -ne "-" -and $_.user -notLike "*`$" } |
  Select -Unique "user"
  } | Select -Unique "user" | Out-File -FilePath $resultsFilePath
}

############################################################
# Mainline


## Change to directory containing the log files
$logspath = "C:\inetpub\logs\LogFiles\W3SVC1"
$logresultspath = $ResultsPathParam + ".log"

## set txt results path if not supplied in params
$txtresultspath = $ResultsPathParam + ".txt"
if (-NOT ($ResultsPathParam))
{
  $txtresultspath = $ScriptPath + ".txt"
  $logresultspath = $ScriptPath + ".log"
}
 
## remove any old check run results
if (Test-Path $txtresultspath) {
   Remove-Item $txtresultspath
} 
 
## report ScriptInfo
## *************************
## 262.USER LOGIND
## *************************
Write-ScriptInfo

## check IIS for user logins
Write-Result "********************"
Write-Result "262.USER LOGINS"
Write-Result "********************"
Write-Result ""

SearchLogFiles $logspath $logresultspath

## read result log
$logs = Get-Content -Path $logresultspath
$logs.ForEach( { Write-Result $_ } )

del $logresultspath

Write-Result ""

