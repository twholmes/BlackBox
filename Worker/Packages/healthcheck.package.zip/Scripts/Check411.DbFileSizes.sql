---------------------------------------------------------------------------
-- Copyright (C) 2024 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: Database File Sizes
-- Check Number: 4.1.1
-- Updated: 12/02/2024 19:15
---------------------------------------------------------------------------

--USE FNMSCompliance

SELECT 
  DB_NAME( dbid ) AS DatabaseName, 
	[filename],
  CAST( ( size * 8 ) / ( 1024.0 ) AS decimal( 10, 2 ) ) AS DbFileMb 
FROM 
  sys.sysaltfiles 
WHERE
DB_NAME( dbid ) like 'FNMS%'

GO
