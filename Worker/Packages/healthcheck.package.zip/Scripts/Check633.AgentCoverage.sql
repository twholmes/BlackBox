---------------------------------------------------------------------------
-- Copyright (C) 2024 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: Agent Deployment Coverage
-- Check Number: 6.3.3
-- Updated: 24/07/2023 12:15
---------------------------------------------------------------------------

--USE FNMSCompliance

------------------------------------------------------------------------------------------ 
-- Agent Deployment Coverage
------------------------------------------------------------------------------------------

SELECT 
  r. ADContainerType, 
  COUNT(*) AS NumberOfDevices,
  SUM(r.HaveAgentInventory) AS NumberOfDevicesWithAgent
FROM (
  SELECT 
    cd.ComputerCN,
    CASE
      WHEN cd.OURDN LIKE '%Servers%' 
      THEN 'Server'
      WHEN cd.OURDN LIKE '%Domain Controllers%' 
      THEN 'Domain Controller'
      WHEN cd.OURDN LIKE '%Managed Desktops%' 
      THEN 'Managed Desktop'
      WHEN cd.OURDN LIKE '%Labs%' 
      THEN 'Lab'
      WHEN cd.OURDN LIKE '%Special Purpose Computers%' 
      THEN 'Special Purpose Computer'
      WHEN cd.OURDN LIKE '%New Builds%' 
      THEN 'New Build'
      WHEN cd.OURDN LIKE '%Virtual Desktops%' 
      THEN 'Virtual Desktop'
      WHEN cd.OURDN LIKE '%-Computers%' 
      THEN '<Faculty>-Computer'
      WHEN cd.OURDN LIKE '% Computers%' 
      THEN '<Faculty>-Computer'
      WHEN cd.OURDN LIKE '%Deployed Virtual Machines%' 
      THEN 'Deployed Virtual Machine'
      WHEN cd.OURDN LIKE '%Homeless Computers%' 
      THEN 'Homeless Computer'
      WHEN cd.OURDN LIKE '%CN=Computer%' 
      THEN 'Computer'
      WHEN cd.OURDN LIKE '%Central and SLA Services%' 
      THEN 'Central and SLA Services'
      WHEN ISNULL(cd.OURDN,'') = '' 
      THEN 'No organisational unit'
      ELSE 'Unspecified'
    END AS ADContainerType,
    CASE
      WHEN ir.HWDate IS NOT NULL THEN 1
      ELSE 0
    END AS HaveAgentInventory
  FROM ComputerDirectory cd
    LEFT OUTER JOIN InventoryReport ir
      ON ir.ComputerID = cd.ComputerID
  WHERE cd.GUID IS NOT NULL
) r
GROUP BY r.ADContainerType
ORDER BY r.ADContainerType

GO
