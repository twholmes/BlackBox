---------------------------------------------------------------------------
-- Copyright (C) 2024 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: Beacon Import Results
-- Check Number: 3.1.4
-- Updated: 01/02/2024 20:15
---------------------------------------------------------------------------

--USE FNMSCompliance

------------------------------------------------------------------------------------------ 
-- Beacon Import Results
------------------------------------------------------------------------------------------

SELECT 
  bir.[BusinessImportResultID]
  ,bir.[ImportName]
  ,bir.[BeaconID]
  ,bir.[ImportStarted]
  ,bir.[ImportEnded]
  ,bir.[Result]
FROM [dbo].[BusinessImportResult] as bir

GO
