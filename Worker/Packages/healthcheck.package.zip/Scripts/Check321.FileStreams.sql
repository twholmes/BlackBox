---------------------------------------------------------------------------
-- Copyright (C) 2024 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: Beacon File Streams
-- Check Number: 3.3.1
-- Updated: 91/02/2024 20:15
---------------------------------------------------------------------------

--USE FNMSCompliance

------------------------------------------------------------------------------------------ 
-- Beacon File Streams
------------------------------------------------------------------------------------------

SELECT  
  gvb.[BeaconID]
  ,b.BeaconName
  ,gvb.[ImportType]
  ,gvb.[Count]
  ,gvb.[TotalSize]
  ,gvb.[MaxAge]
  ,gvb.[MinAge]
FROM [dbo].[Grid_ViewBeaconPropertyValues] as gvb
 JOIN dbo.Beacon_MT as b on gvb.BeaconID = b.BeaconID
ORDER by gvb.BeaconID

GO
