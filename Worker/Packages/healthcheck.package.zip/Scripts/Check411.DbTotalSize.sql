---------------------------------------------------------------------------
-- Copyright (C) 2024 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: Total Database Sizes
-- Check Number: 4.1.5
-- Updated: 12/02/2024 19:00
---------------------------------------------------------------------------

--USE FNMSCompliance

SELECT 
  DB_NAME( dbid ) AS DatabaseName, 
  CAST( ( SUM( size ) * 8 ) / ( 1024.0 * 1024.0 ) AS decimal( 10, 2 ) ) AS DbSizeGb 
FROM 
  sys.sysaltfiles 
GROUP BY 
  DB_NAME( dbid )

GO
