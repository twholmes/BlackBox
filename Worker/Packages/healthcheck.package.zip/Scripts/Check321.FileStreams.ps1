##-------------------------------------------------------------------------
## Copyright (C) 2024 Crayon Australia
## This script runs an FNMS Health Check procedure
## Check Name: Beacon File Streams
## Check Number: 3.2.1
## Updated: 31/01/2024 20:55
##-------------------------------------------------------------------------

## Get this script name and path
$Global:ScriptName = $MyInvocation.MyCommand.Name
$Global:ScriptPath = $MyInvocation.MyCommand.Path

$Global:ResultsPath = $MyInvocation.MyCommand.Path + ".txt"

###########################################################################
## GENERIC CODE - DONT EDIT THIS SECTION ##
Import-Module -Force (Join-Path  (Split-Path $script:MyInvocation.MyCommand.Path) 'CUA-functions.psm1')

############################################################
# Check folder for files greater than N days

function CheckFileAges([string]$filePath, [int]$days)
{
  cd $filePath

  $files = Get-ChildItem $filePath -File
  $limit = [datetime]::Now.AddDays(-$days)
  $count = 0
  foreach($file in $files) 
  {
    if ($file.CreationTime -lt $limit) 
    {
      $count++
    }
  }
  Write-Result ('{0} files older than {1} days' -f $count, $days)
}

############################################################
# Check folder for a file age profile

function CheckFolderFileAgeProfile([string]$folder)
{
  cd $folder

  $filecount = (Get-ChildItem $folder | Measure-Object ).Count
  if ($filecount -gt 10000)
  {
    Write-Result ("Directory {0} contains more that 10000 files" -f $filecount)
  }
  else
  {
    Write-Result ("Check file ages in: {0}" -f $folder)
    Write-Result ("{0} files" -f $filecount) 
    CheckFileAges $folder 365
    CheckFileAges $folder 180
    CheckFileAges $folder 90
    CheckFileAges $folder 30
  }
  Write-Result ""
}

############################################################
# Check folder for a file age profile

function RecurseCheckFolderFileAgeProfile([string]$filePath)
{ 
  if (!(Test-Path -Path $filePath))
  {
    Write-Result ("The directory {0} does not exist" -f $filePath)
  }
  else
  {
    cd $filePath

    $parent = (Get-ChildItem $filePath).Directory
    CheckFolderFileAgeProfile $filePath

    $subfolders = Get-ChildItem -Recurse -Directory -Path $filePath | Select-Object FullName
    foreach ($folder in $subfolders)
    {
      CheckFolderFileAgeProfile $folder.FullName
    }
  }
  Write-Result ""
}

############################################################
# Mainline

## set txt results path if not supplied in params
$scriptdir = Split-Path -parent $MyInvocation.MyCommand.Definition
$parts = $ScriptName.split(".", 3)
$Global:ResultsPath = $scriptdir + "\" + $parts[0] + "." + $env:COMPUTERNAME + "." + $parts[1] + ".txt"
 
## remove any old check run results
if (Test-Path $ResultsPath) {
  Remove-Item $ResultsPath
}

## report ScriptInfo
## *************************
## 321.BEACON FILE STREAMS
## *************************
Write-ScriptInfo

## database connecion parameters
$dbcs = ""
$dbserver = "localhost"
$database = "FNMSCompliance"

## get sql connection details frpm the registry
$regKeyPath = 'Registry::HKLM\SOFTWARE\WOW6432Node\ManageSoft Corp\ManageSoft\Reporter\CurrentVersion'
$regExists = (Get-Item $regKeyPath -EA Ignore).Property -contains "DatabaseConnectionString"
if ($regExists)
{
  $dbcs = Get-ItemPropertyValue -Path $regKeyPath -Name DatabaseConnectionString
  $params = $dbcs -split ";"
  $param1 = $params[1] -split "="
  $param2 = $params[1] -split "="  
  
  if ($param1[0] -eq "Server") { $dbserver = $param1[1] }
  #Write-Host $dbserver
  if ($param1[0] -eq "Database") { $database = $param2[1] }
  #Write-Host $database
}

## export the inventory connections
Write-Result "*************************"
Write-Result "321.BEACON FILE STREAMS"
Write-Result "*************************"
Write-Result ""

## run the query to find the Business Data Import Results
& SQLCMD.EXE -S $dbserver -d $database -i Check321.FileStreams.sql -o Check321.FileStreams.csv -s "," -W

## read beacon import results
$csv = Get-Content -Path ".\Check321.FileStreams.csv"
$csv.ForEach( { Write-Result $_ } )

Write-Result ""

## check fnms compliance incomming folders
Write-Result "**********************"
Write-Result "321.INCOMING FILE AGES"
Write-Result "**********************"
Write-Result ""

$incoming = Get-ItemPropertyValue -Path 'Registry::HKLM\SOFTWARE\WOW6432Node\ManageSoft Corp\ManageSoft\Common' -Name UploadDirectory
RecurseCheckFolderFileAgeProfile ("{0}\ActionStatus" -f $incoming)
RecurseCheckFolderFileAgeProfile ("{0}\ActiveDirectory" -f $incoming)
RecurseCheckFolderFileAgeProfile ("{0}\ActivityStatus" -f $incoming)
RecurseCheckFolderFileAgeProfile ("{0}\BeaconStatus" -f $incoming)
RecurseCheckFolderFileAgeProfile ("{0}\ClientAccess" -f $incoming)
RecurseCheckFolderFileAgeProfile ("{0}\Discovery" -f $incoming)
RecurseCheckFolderFileAgeProfile ("{0}\Distributor" -f $incoming)
RecurseCheckFolderFileAgeProfile ("{0}\Inventories" -f $incoming)
RecurseCheckFolderFileAgeProfile ("{0}\Logs" -f $incoming)
RecurseCheckFolderFileAgeProfile ("{0}\PolicyComplianceLogs" -f $incoming)
RecurseCheckFolderFileAgeProfile ("{0}\RawUsageData" -f $incoming)
RecurseCheckFolderFileAgeProfile ("{0}\RemoteApplication" -f $incoming)
RecurseCheckFolderFileAgeProfile ("{0}\SecurityAnalysis" -f $incoming)
RecurseCheckFolderFileAgeProfile ("{0}\SecurityEventLogs" -f $incoming)
RecurseCheckFolderFileAgeProfile ("{0}\SMSStatusMessages" -f $incoming)
RecurseCheckFolderFileAgeProfile ("{0}\UsageData" -f $incoming)
RecurseCheckFolderFileAgeProfile ("{0}\VdiAccess" -f $incoming)

Write-Result ""
