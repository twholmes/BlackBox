---------------------------------------------------------------------------
-- Copyright (C) 2024 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: Inventory Age
-- Check Number: 6.3.1
-- Updated: 12/02/2024 22:15
---------------------------------------------------------------------------

--USE FNMSCompliance

------------------------------------------------------------------------------------------ 
-- Inventory Age Profile
------------------------------------------------------------------------------------------

SELECT	
  DATEDIFF(m, c.InventoryDate, GETDATE()) AS MonthsOld
  ,COUNT(c.ComplianceComputerID) AS Count
FROM dbo.ComplianceComputer c
WHERE	c.ComplianceComputerStatusID = 1 /* active */ AND c.InventoryDate IS NOT NULL
GROUP BY DATEDIFF(m, c.InventoryDate, GETDATE())
ORDER BY DATEDIFF(m, c.InventoryDate, GETDATE())

GO
