##-------------------------------------------------------------------------
## Copyright (C) 2024 Crayon Australia
## This script runs an FNMS Health Check procedure
## Check Name: Business Data Imports
## Check Number: 3.1.6
## Updated: 11/02/2024 13:20
##-------------------------------------------------------------------------

## Get this script name and path
$Global:ScriptName = $MyInvocation.MyCommand.Name
$Global:ScriptPath = $MyInvocation.MyCommand.Path

$Global:ResultsPath = $MyInvocation.MyCommand.Path + ".txt"

################################################################################################
## GENERIC CODE - DONT EDIT THIS SECTION ##
Import-Module -Force (Join-Path  (Split-Path $script:MyInvocation.MyCommand.Path) 'CUA-functions.psm1')

############################################################
# Mainline

## set txt results path if not supplied in params
$scriptdir = Split-Path -parent $MyInvocation.MyCommand.Definition
$parts = $ScriptName.split(".", 3)
$Global:ResultsPath = $scriptdir + "\" + $parts[0] + "." + $env:COMPUTERNAME + "." + $parts[1] + ".txt"
 
## remove any old check run results
if (Test-Path $ResultsPath) {
  Remove-Item $ResultsPath
} 
  
## report ScriptInfo
## *************************
## 316.SCRIPT INFO
## *************************
Write-ScriptInfo

## database connecion parameters
$dbcs = ""
$dbserver = "localhost"
$database = "FNMSCompliance"

## get sql connection details frpm the registry
$regKeyPath = 'Registry::HKLM\SOFTWARE\WOW6432Node\ManageSoft Corp\ManageSoft\Reporter\CurrentVersion'
$regExists = (Get-Item $regKeyPath -EA Ignore).Property -contains "DatabaseConnectionString"
if ($regExists)
{
  $dbcs = Get-ItemPropertyValue -Path $regKeyPath -Name DatabaseConnectionString
  $params = $dbcs -split ";"
  $param1 = $params[1] -split "="
  $param2 = $params[1] -split "="  
  
  if ($param1[0] -eq "Server") { $dbserver = $param1[1] }
  #Write-Host $dbserver
  if ($param1[0] -eq "Database") { $database = $param2[1] }
  #Write-Host $database
}

## export the inventory connections
Write-Result "*************************"
Write-Result "316.BUSINESS DATA IMPORTS"
Write-Result "*************************"
Write-Result ""

## run the query to find the Business Data Import Results
& SQLCMD.EXE -S $dbserver -d $database -i Check316.BusinessDataImports.sql -o Check316.BusinessDataImports.csv -s "," -W

## read beacon import results
$csv = Get-Content -Path ".\Check316.BusinessDataImports.csv"
$csv.ForEach( { Write-Result $_ } )

Write-Result ""
