##-------------------------------------------------------------------------
## Copyright (C) 2024 Crayon Australia
## This script runs an FNMS Health Check procedure
## Check Name: Logged Errors
## Check Number: 3.3.1
## Updated: 30/01/2024 20:55
##-------------------------------------------------------------------------

## Get this script name and path
$Global:ScriptName = $MyInvocation.MyCommand.Name
$Global:ScriptPath = $MyInvocation.MyCommand.Path

$Global:ResultsPath = $MyInvocation.MyCommand.Path + ".txt"

###########################################################################
## GENERIC CODE - DONT EDIT THIS SECTION ##
Import-Module -Force (Join-Path  (Split-Path $script:MyInvocation.MyCommand.Path) 'CUA-functions.psm1')

############################################################
# Check folder for log files containing errors

function CheckFolderFilesForErrors([string]$filePath)
{ 
  if (!(Test-Path -Path $filePath))
  {
    Write-Result ("The directory {0} does not exist" -f $filePath)
  }
  else
  {
    cd $filePath
    try
    {
      ## The following code snippet gets all the files in $filePath that end in ".log".
      $PathArray = @()
      Get-ChildItem $filePath -Filter "*.log" |
      Where-Object { $_.Attributes -ne "Directory"} |
      ForEach-Object {
        If (Get-Content $_.FullName -Force -ErrorAction Stop | Select-String -Pattern "[Error]" -SimpleMatch) {
          $PathArray += $_.FullName
        }
      }
      Write-Result ("Files containing errors: {0}" -f $filePath)
      foreach ($filename in $PathArray)
      {
        Write-Result ("{0}" -f $filename)
      }
    }
    catch
    {
      Write-Result ("Error parsing files for errors: {0}" -f $filePath)    
    }
    Write-Result ""    
  }
}

############################################################
# Mainline

## set txt results path if not supplied in params
$scriptdir = Split-Path -parent $MyInvocation.MyCommand.Definition
$parts = $ScriptName.split(".", 3)
$Global:ResultsPath = $scriptdir + "\" + $parts[0] + "." + $env:COMPUTERNAME + "." + $parts[1] + ".txt"
 
## remove any old check run results
if (Test-Path $ResultsPath) {
  Remove-Item $ResultsPath
}
  
## report ScriptInfo
## *************************
## 331.LOGGED ERRORS
## *************************
Write-ScriptInfo

## check fnms compliance log folders
Write-Result "********************"
Write-Result "331.LOGFILE ERRORS"
Write-Result "********************"
Write-Result ""

$mgslogs = Get-ItemPropertyValue -Path 'Registry::HKLM\SOFTWARE\WOW6432Node\ManageSoft Corp\ManageSoft\Compliance\CurrentVersion' -Name LoggingBaseDirectory
CheckFolderFilesForErrors ("{0}\ActiveDirectoryImport" -f $mgslogs)
CheckFolderFilesForErrors ("{0}\ActiveDirectoryImport" -f $mgslogs)
CheckFolderFilesForErrors ("{0}\BatchProcessScheduler" -f $mgslogs)
CheckFolderFilesForErrors ("{0}\BatchProcessTask" -f $mgslogs)
CheckFolderFilesForErrors ("{0}\BeaconEngine" -f $mgslogs)
CheckFolderFilesForErrors ("{0}\ComplianceReader" -f $mgslogs)
CheckFolderFilesForErrors ("{0}\ComplianceUpload" -f $mgslogs)
CheckFolderFilesForErrors ("{0}\ConfigureSystem" -f $mgslogs)
CheckFolderFilesForErrors ("{0}\Content" -f $mgslogs)
CheckFolderFilesForErrors ("{0}\InventoryBeacon" -f $mgslogs)
CheckFolderFilesForErrors ("{0}\InventoryBeacons" -f $mgslogs)
CheckFolderFilesForErrors ("{0}\FlxBizAdapterImporter" -f $mgslogs)
CheckFolderFilesForErrors ("{0}\Maintenance" -f $mgslogs)
CheckFolderFilesForErrors ("{0}\SAPReader" -f $mgslogs)
CheckFolderFilesForErrors ("{0}\WebResolvers" -f $mgslogs)
CheckFolderFilesForErrors ("{0}\WebUI" -f $mgslogs)
