##-------------------------------------------------------------------------
## Copyright (C) 2024 Crayon Australia
## This script runs an FNMS Health Check procedure
## Check Name: Log File Ages
## Check Number: 3.3.1
## Updated: 31/01/2024 20:55
##-------------------------------------------------------------------------

## Get this script name and path
$Global:ScriptName = $MyInvocation.MyCommand.Name
$Global:ScriptPath = $MyInvocation.MyCommand.Path

$Global:ResultsPath = $MyInvocation.MyCommand.Path + ".txt"

###########################################################################
## GENERIC CODE - DONT EDIT THIS SECTION ##
Import-Module -Force (Join-Path  (Split-Path $script:MyInvocation.MyCommand.Path) 'CUA-functions.psm1')

############################################################
# Check folder for files greater than N days

function CheckFileAges([string]$filePath, [int]$days)
{
  cd $filePath

  $files = Get-ChildItem $filePath -File
  $limit = [datetime]::Now.AddDays(-$days)
  $count = 0
  foreach($file in $files) 
  {
    if ($file.CreationTime -lt $limit) 
    {
      $count++
    }
  }
  Write-Result ('{0} files older than {1} days' -f $count, $days)
}

############################################################
# Check folder for a file age profile

function CheckFolderFileAgeProfile([string]$folder)
{
  cd $folder

  $filecount = (Get-ChildItem $folder | Measure-Object ).Count
  if ($filecount -gt 10000)
  {
    Write-Result ("Directory {0} contains more that 10000 files" -f $filecount)
  }
  else
  {
    Write-Result ("Check file ages in: {0}" -f $folder)
    Write-Result ("{0} files" -f $filecount) 
    CheckFileAges $folder 365
    CheckFileAges $folder 180
    CheckFileAges $folder 90
    CheckFileAges $folder 30
  }
  Write-Result ""
}

############################################################
# Check folder for a file age profile

function RecurseCheckFolderFileAgeProfile([string]$filePath)
{ 
  if (!(Test-Path -Path $filePath))
  {
    Write-Result ("The directory {0} does not exist" -f $filePath)
  }
  else
  {
    cd $filePath

    $parent = (Get-ChildItem $filePath).Directory
    CheckFolderFileAgeProfile $filePath

    $subfolders = Get-ChildItem -Recurse -Directory -Path $filePath | Select-Object FullName
    foreach ($folder in $subfolders)
    {
      CheckFolderFileAgeProfile $folder.FullName
    }
  }
  Write-Result ""
}

############################################################
# Mainline

## set txt results path if not supplied in params
$scriptdir = Split-Path -parent $MyInvocation.MyCommand.Definition
$parts = $ScriptName.split(".", 3)
$Global:ResultsPath = $scriptdir + "\" + $parts[0] + "." + $env:COMPUTERNAME + "." + $parts[1] + ".txt"
 
## remove any old check run results
if (Test-Path $ResultsPath) {
  Remove-Item $ResultsPath
}
 
## report ScriptInfo
## *************************
## 331.LOG FILE AGES
## *************************
Write-ScriptInfo

## check file ages in a directory
Write-Result "********************"
Write-Result "331.LOG FILE AGES"
Write-Result "********************"
Write-Result ""

CheckFolderFileAgeProfile ".\"

## check fnms compliance log folders
$mgslogs = Get-ItemPropertyValue -Path 'Registry::HKLM\SOFTWARE\WOW6432Node\ManageSoft Corp\ManageSoft\Compliance\CurrentVersion' -Name LoggingBaseDirectory
RecurseCheckFolderFileAgeProfile ("{0}\ActiveDirectoryImport" -f $mgslogs)
RecurseCheckFolderFileAgeProfile ("{0}\BatchProcessScheduler" -f $mgslogs)
RecurseCheckFolderFileAgeProfile ("{0}\BatchProcessTask" -f $mgslogs)
RecurseCheckFolderFileAgeProfile ("{0}\BeaconEngine" -f $mgslogs)
RecurseCheckFolderFileAgeProfile ("{0}\ComplianceReader" -f $mgslogs)
RecurseCheckFolderFileAgeProfile ("{0}\ComplianceUpload" -f $mgslogs)
RecurseCheckFolderFileAgeProfile ("{0}\ConfigureSystem" -f $mgslogs)
RecurseCheckFolderFileAgeProfile ("{0}\Content" -f $mgslogs)
RecurseCheckFolderFileAgeProfile ("{0}\InventoryBeacon" -f $mgslogs)
RecurseCheckFolderFileAgeProfile ("{0}\InventoryBeacons" -f $mgslogs)
RecurseCheckFolderFileAgeProfile ("{0}\FlxBizAdapterImporter" -f $mgslogs)
RecurseCheckFolderFileAgeProfile ("{0}\Maintenance" -f $mgslogs)
RecurseCheckFolderFileAgeProfile ("{0}\SAPReader" -f $mgslogs)
RecurseCheckFolderFileAgeProfile ("{0}\WebResolvers" -f $mgslogs)
RecurseCheckFolderFileAgeProfile ("{0}\WebUI" -f $mgslogs)

