##-------------------------------------------------------------------------
## Copyright (C) 2024 Crayon Australia
## This script runs an FNMS Health Check procedure
## Check Name: Windows Features
## Check Number: 3.1.1
## Updated: 11/02/2024 13:35
##-------------------------------------------------------------------------

## Get this script name and path
$Global:ScriptName = $MyInvocation.MyCommand.Name
$Global:ScriptPath = $MyInvocation.MyCommand.Path

$Global:ResultsPath = $MyInvocation.MyCommand.Path + ".txt"

################################################################################################
## GENERIC CODE - DONT EDIT THIS SECTION ##
Import-Module -Force (Join-Path  (Split-Path $script:MyInvocation.MyCommand.Path) 'CUA-functions.psm1')

############################################################
# Mainline

## set txt results path if not supplied in params
$scriptdir = Split-Path -parent $MyInvocation.MyCommand.Definition
$parts = $ScriptName.split(".", 3)
$Global:ResultsPath = $scriptdir + "\" + $parts[0] + "." + $env:COMPUTERNAME + "." + $parts[1] + ".txt"
 
## remove any old check run results
if (Test-Path $ResultsPath) {
  Remove-Item $ResultsPath
} 
 
## report ScriptInfo
## *************************
## 311.SCRIPT INFO
## *************************
Write-ScriptInfo

## export the windows feature install status
Write-Result "********************"
Write-Result "311.WINDOWS FEATURES"
Write-Result "********************"
Write-Result ""

Write-Result ">> FEATURES INSTALLED"
Get-WindowsOptionalFeature -Online | where {$_.state -eq "Enabled"} | ft -Property featurename | Out-File ".\features.installed.txt"
$features = Get-Content -Path ".\features.installed.txt"
$features.ForEach( { Write-Result $_ } )
del ".\features.installed.txt"

Write-Result ">> FEATURES AVAILABLE BUT NOT INSTALLED"
Get-WindowsOptionalFeature -Online | where {$_.state -eq "Disabled"} | ft -Property featurename | Out-File ".\features.available.txt"
$features = Get-Content -Path ".\features.available.txt"
$features.ForEach( { Write-Result $_ } )
del ".\features.available.txt"

Write-Result ""
