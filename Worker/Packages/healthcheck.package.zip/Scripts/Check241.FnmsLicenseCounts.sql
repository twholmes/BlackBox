---------------------------------------------------------------------------
-- Copyright (C) 2024 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: FNMS License Counts
-- Check Number: 2.4.1
-- Updated: 04/02/2024 20:55
---------------------------------------------------------------------------

--USE FNMSCompliance

------------------------------------------------------------------------------------------ 
-- FNMS License Counts
------------------------------------------------------------------------------------------

DECLARE @ResultCount int
SET @ResultCount = (SELECT COUNT(*) FROM ComplianceComputerActiveForLicenseReconcile)
PRINT 'Compliance Computer Active For License Reconcile = ' + convert(nvarchar(5), @ResultCount)

SET @ResultCount = (SELECT COUNT(*) FROM ComplianceServersActiveList)
PRINT 'Compliance Servers Active List = ' + convert(nvarchar(5), @ResultCount)

GO
