---------------------------------------------------------------------------
-- Copyright (C) 2023 Crayon Australia
-- This script runs an FNMS Health Check procedure
-- Check Name: Database Backup File Sizes
-- Check Number: 4.1.2
-- Updated: 12/02/2024 20:15
---------------------------------------------------------------------------

--USE FNMSCompliance

------------------------------------------------------------------------------------------ 
--Most Recent Database Backup for Each Database 
------------------------------------------------------------------------------------------

SELECT  
  CONVERT(CHAR(100), SERVERPROPERTY('Servername')) AS Server, 
  msdb.dbo.backupset.database_name,  
  MAX(msdb.dbo.backupset.backup_finish_date) AS last_db_backup_date 
FROM 
  msdb.dbo.backupmediafamily  
  INNER JOIN msdb.dbo.backupset ON msdb.dbo.backupmediafamily.media_set_id = msdb.dbo.backupset.media_set_id  
WHERE msdb..backupset.type = 'D' 
GROUP BY 
  msdb.dbo.backupset.database_name  
ORDER BY  
  msdb.dbo.backupset.database_name

GO
