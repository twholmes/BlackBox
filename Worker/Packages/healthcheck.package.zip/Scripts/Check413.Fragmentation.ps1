##-------------------------------------------------------------------------
## Copyright (C) 2024 Crayon Australia
## This script runs an FNMS Health Check procedure
## Check Name: Check Database Fragmentation
## Check Number: 4.1.3
## Updated: 12/02/2024 20:00
##-------------------------------------------------------------------------

param(
  [string]$LogsPathParam
  , [string]$ResultsPathParam  
)

## Get this script name and path
$Global:ScriptName = $MyInvocation.MyCommand.Name
$Global:ScriptPath = $MyInvocation.MyCommand.Path

###########################################################################
## GENERIC CODE - DONT EDIT THIS SECTION ##
Import-Module -Force (Join-Path  (Split-Path $script:MyInvocation.MyCommand.Path) 'CUA-functions.psm1')

###########################################################################
# Mainline

#WriteLog "LogsPathParam = $LogsPathParam"
#WriteLog "ResultsPathParam = $ResultsPathParam"
#WriteLog ""

## set txt results path if not supplied in params
$txtresultspath = $ResultsPathParam + ".txt"
if (-NOT ($ResultsPathParam))
{
  $txtresultspath = $ScriptPath + ".txt"
}
 
## remove any old check run results
if (Test-Path $txtresultspath) {
   Remove-Item $txtresultspath
} 
  
## report ScriptInfo
## ***************************
## 413.DATABASE FRAGMENTATION
## ***************************
Write-ScriptInfo

## database connecion parameters
$dbcs = ""
$dbserver = "localhost"
$database = "FNMSCompliance"

## export custom properties
Write-Result "********************************"
Write-Result "413.COMPLIANCE DB FRAGMENTATION"
Write-Result "********************************"
Write-Result ""

## get sql connection details frpm the registry
$regKeyPath = 'Registry::HKLM\SOFTWARE\WOW6432Node\ManageSoft Corp\ManageSoft\Reporter\CurrentVersion'
$regExists = (Get-Item $regKeyPath -EA Ignore).Property -contains "DatabaseConnectionString"
if ($regExists)
{
  $dbcs = Get-ItemPropertyValue -Path $regKeyPath -Name DatabaseConnectionString
  $params = $dbcs -split ";"
  $param1 = $params[1] -split "="
  $param2 = $params[1] -split "="  
  
  if ($param1[0] -eq "Server") { $dbserver = $param1[1] }
  #Write-Host $dbserver
  if ($param1[0] -eq "Database") { $database = $param2[1] }
  #Write-Host $database
}

## run the query to find compliance settings data
& SQLCMD.EXE -S $dbserver -d $database -i Check413.Fragmentation.sql -o Check413.ComplianceDbFragmentation.csv -s "," -W

## read custom asset property list
$csv = Get-Content -Path ".\Check413.ComplianceDbFragmentation.csv"
$csv.ForEach( { Write-Result $_ } )

Write-Result ""

## export custom properties
Write-Result "********************************"
Write-Result "413.INVENTORY DB FRAGMENTATION"
Write-Result "********************************"
Write-Result ""

## get sql connection details frpm the registry
$regKeyPath = 'Registry::HKLM\SOFTWARE\WOW6432Node\ManageSoft Corp\ManageSoft\Reporter\CurrentVersion'
$regExists = (Get-Item $regKeyPath -EA Ignore).Property -contains "DatabaseConnectionString"
if ($regExists)
{
  $dbcs = Get-ItemPropertyValue -Path $regKeyPath -Name InventoryDatabaseConnectionString
  $params = $dbcs -split ";"
  $param1 = $params[1] -split "="
  $param2 = $params[1] -split "="  
  
  if ($param1[0] -eq "Server") { $dbserver = $param1[1] }
  #Write-Host $dbserver
  if ($param1[0] -eq "Database") { $database = $param2[1] }
  #Write-Host $database
}

## run the query to find compliance settings data
& SQLCMD.EXE -S $dbserver -d $database -i Check413.Fragmentation.sql -o Check413.InvDbFragmentation.csv -s "," -W

## read custom asset property list
$csv = Get-Content -Path ".\Check413.InvDbFragmentation.csv"
$csv.ForEach( { Write-Result $_ } )

Write-Result ""
