REM Commandline: ScriptRunner.exe
REM [-Setup] [-unzip] [-clean] [-days <num1>] [-months <num2>]
REM [-Help]
REM [-List] [-catalog <catalog>]
REM [-ListDetails] [-catalog <catalog>]
REM [-Run] [-catalog <catalog>] [-item <n>] [-uc <usecase>] [-runas] [-account <domain/user>] [-domain <domain>] [-user <user>] [-password <password>]
REM [-Run] [-catalog <catalog>] [-runas] [-account <domain/user>] [-domain <domain>] [-user <user>] [-password <password>]
REM [-Test]
      
REM "Options:");      
REM [-simulate]"));
REM [-database],[-nodatabase],[-csv],[-nocsv]"));
REM [-runas],[-account <domain/user>],[-domain <domain>],[-user <user>],[-password <password>]"));
REM [-unzip],[-clean],[-days <num1>],[-months <num2>]")); 
REM [-nowindow],[-verbose],[-debug]"));      

REM use the following command to clear logs
REM netsh http flush logbuffer


REM ==============
REM EXAMPLES
REM ==============

Example: Cleanup task
..\..\BlackBoxWorker.exe -task cleanup.task.xml -run -guid -local -debug

Example: Workday job
..\..\BlackBoxWorker.exe -job workday.job.xml -run -guid -local -debug