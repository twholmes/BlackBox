---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export WMI Evidence
-- Export Number: 2.11
-- Updated: 12/09/2023 14:15
---------------------------------------------------------------------------

--USE FNMSCompliance

WITH WMIEvidenceInfo AS
(
  SELECT 
    ie.[ExternalEvidenceID]  
    ,ie.[ComplianceConnectionID]
    ,iie.[ExternalComputerID] as [ComputerID]
    ,ie.[ClassName]
    ,ie.[PropertyName]
    ,ie.[PropertyValue]
    ,iie.[InstanceName]
  FROM dbo.[ImportedWMIEvidence] as ie
   LEFT OUTER JOIN dbo.[ImportedInstalledWMIEvidence] as iie on iie.[ComplianceConnectionID] = ie.[ComplianceConnectionID] and iie.[ExternalEvidenceID] = ie.[ExternalEvidenceID]
)
SELECT
  wmi.[ComputerID],
  wmi.[ClassName],
  wmi.[PropertyName],
  wmi.[PropertyValue],
  wmi.[InstanceName]
FROM WMIEvidenceInfo as wmi
WHERE wmi.[ComplianceConnectionID] = 3