---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export WMI Evidence
-- Export Number: 2.11
-- Updated: 12/09/2023 14:15
---------------------------------------------------------------------------

--USE FNMSCompliance

WITH WMIEvidenceInfo AS
(
  SELECT
    ie.[WMIEvidenceID]
    ,ie.[ComplianceComputerID] as [ComputerID]
    ,ie.[AccessModeID]
    ,ie.[InstanceName]
    ,we.[ClassName]
    ,we.[PropertyName]
    ,we.[PropertyValue]    
    ,we.[Ignored]
  FROM dbo.[InstalledWMIEvidence] as ie
    LEFT OUTER JOIN dbo.[WMIEvidence] as we on we.[WMIEvidenceID] = ie.[WMIEvidenceID]
)
SELECT
  wmi.[ComputerID],
  wmi.[ClassName],
  wmi.[PropertyName],
  wmi.[PropertyValue],
  wmi.[InstanceName]
FROM WMIEvidenceInfo as wmi
