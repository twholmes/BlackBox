---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export Users
-- Export Number: 1.21
-- Updated: 11/09/2023 14:15
---------------------------------------------------------------------------

--USE FNMSCompliance

SELECT 
  cu.[ComplianceUserID],
  ISNULL(cu.[UserName], cu.[SAMAccountName]) as [UserName],
  cu.[FirstName],
  cu.[MiddleName],
  cu.[LastName],
  cu.[SAMAccountName],
  cd.[QualifiedName] AS [Domain],
  cd.[FlatName] AS [DomainFlatName],
  cu.[EmployeeNumber],
  cu.[JobTitle],
  cus.[DefaultValue] AS [UserStatus],
  es.[DefaultValue] AS [EmploymentStatus],
  cu.[IsIncluded],
  CAST(0 AS bit) AS [IsOperator], 
  man.[UserName] AS [Manager],
  ut.[DefaultValue] AS [Title],
  us.[DefaultValue] AS [Suffix],
  cu.[BusinessPhoneNumber] as [PhoneNo],
  cu.[MobilePhoneNumber] as [MobileNo],
  cu.[FaxPhoneNumber] as [FaxNo],
  cu.[Address_Street] as [AddressStreet],
  cu.[Address_City] as [AddressCity],
  cu.[Address_State] as [AddressState],
  cu.[Address_ZIP] as [AddressZip],
  cu.[Address_Country] as [AddressCountry],
  cu.[Email],
  cu.[Messenger],
  cu.[AlternateEmail],
  loc.[Path] AS [Location],
  cc.[Path] AS [CostCenter],
  dep.[Path] AS [BusinessUnit],
  cat.[Path] AS [Category],
  cu.[InventoryAgent],  
  cu.[CreationUser],
  cu.[CreationDate],
  cu.[UpdatedUser],
  cu.[UpdatedDate]
 FROM [dbo].[ComplianceUser] AS cu
   LEFT OUTER JOIN [dbo].[ComplianceDomain] AS cd ON cd.[ComplianceDomainID] = cu.[ComplianceDomainID]
   LEFT OUTER JOIN [dbo].[ComplianceUser] man ON man.[ComplianceUserID] = cu.[ManagerID]
   LEFT OUTER JOIN [dbo].[ComplianceUserStatusI18N] cus ON cus.[ComplianceUserStatusID] = cu.[UserStatusID]
   LEFT OUTER JOIN [dbo].[EmploymentStatusI18N] es ON es.[EmploymentStatusID] = cu.[EmploymentStatusID]
   LEFT OUTER JOIN [dbo].[Location] loc ON loc.[GroupExID] = cu.[LocationID]
   LEFT OUTER JOIN [dbo].[CostCenter] cc ON cc.[GroupExID] = cu.[CostCenterID]
   LEFT OUTER JOIN [dbo].[CorporateUnit] dep ON dep.[GroupExID] = cu.[BusinessUnitID]
   LEFT OUTER JOIN [dbo].[Category] AS cat ON cat.[GroupExID] = cu.[CategoryID]
   LEFT OUTER JOIN [dbo].[UserTitleI18N] ut ON ut.[UserTitleID] = cu.[UserTitleID]
   LEFT OUTER JOIN [dbo].[UserSuffixI18N] us ON us.[UserSuffixID] = cu.[UserSuffixID]
