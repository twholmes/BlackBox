---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export Computers
-- Export Number: 2.01
-- Updated: 12/09/2023 14:15
---------------------------------------------------------------------------

--USE FNMSCompliance

WITH ComputerInfo AS
(
  SELECT 
    ic.[ComplianceConnectionID]
    ,ic.[ExternalID]
    ,ic.[ComplianceComputerID]
    ,ISNULL(ic.[ComplianceComputerTypeID], cc.[ComplianceComputerTypeID]) as [ComplianceComputerTypeID]
    ,cc.[IsComplianceComputerTypeIDFromInventory]
    ,cct.DefaultValue as ComplianceComputerTypeName    
    ,ic.[ComputerName]
    ,ic.[ComplianceDomainID]
    ,ic.[Domain]
    ,FlatDomainName = ISNULL(cdc.FlatName, cdu.FlatName)
    ,DomainName = ISNULL(cdc.QualifiedName, cdu.QualifiedName)
    ,cc.ComplianceComputerStatusID
    ,cc.AssetID
    ,ISNULL(ic.[OperatingSystem], cc.[OperatingSystem]) as [OperatingSystem]
    ,ISNULL(ic.[ServicePack], cc.[ServicePack]) as [ServicePack]
    ,ISNULL(ic.[NumberOfProcessors], cc.[NumberOfProcessors]) as [NumberOfProcessors]
    ,ISNULL(ic.[NumberOfCores], cc.[NumberOfCores]) as [NumberOfCores]
    ,ISNULL(ic.[NumberOfSockets], cc.[NumberOfSockets]) as [NumberOfSockets]
    ,ISNULL(ic.[NumberOfLogicalProcessors], cc.[NumberOfLogicalProcessors]) as [NumberOfLogicalProcessors]    
    ,ISNULL(ic.[PartialNumberOfProcessors], cc.[PartialNumberOfProcessors]) as [PartialNumberOfProcessors]
    ,ISNULL(ic.[ProcessorType], cc.[ProcessorType]) as [ProcessorType]    
    ,ISNULL(ic.[MaxClockSpeed], cc.[MaxClockSpeed]) as [MaxClockSpeed]
    ,ISNULL(ic.[TotalMemory], cc.[TotalMemory]) as [TotalMemory]
    ,ISNULL(ic.[ChassisType], ccht.DefaultValue) as [ChassisType]
    ,ISNULL(ic.[NumberOfHardDrives], cc.[NumberOfHardDrives]) as [NumberOfHardDrives]
    ,ISNULL(ic.[TotalDiskSpace], cc.[TotalDiskSpace]) as [TotalDiskSpace]    
    ,ISNULL(ic.[NumberOfNetworkCards], cc.[NumberOfNetworkCards]) as [NumberOfNetworkCards]
    ,ISNULL(ic.[NumberOfDisplayAdapters], cc.[NumberOfDisplayAdapters]) as [NumberOfDisplayAdapters]
    ,ISNULL(ic.[IPAddress], cc.[IPAddress]) as [IPAddress]    
    ,ISNULL(ic.[MACAddress], cc.[MACAddress]) as [MACAddress]
    ,ISNULL(ic.[Manufacturer], cc.[Manufacturer]) as [Manufacturer]
    ,ISNULL(ic.[ModelNo], cc.[ModelNo]) as [ModelNo]
    ,ISNULL(ic.[SerialNo], cc.[SerialNo]) as [SerialNo]
    ,ISNULL(ic.[UUID], cc.[UUID]) as [UUID]
    ,v.[UUID] as [VirtualMachineUUID]

    ,ISNULL(ic.[InventoryDate], cc.[InventoryDate]) as [InventoryDate]    
    ,ic.[HardwareInventoryDate]
    ,ic.[ServicesInventoryDate]
    ,ISNULL(ic.[InventoryAgent], cc.[InventoryAgent]) as [InventoryAgent]
    ,ic.[AgentVersion]
    ,ic.[ILMTAgentID]
    ,ic.[FNMPComputerUID]
    
    ,ic.[LastLoggedOnUser]
    ,cc.AssignedUserID
    --,cc.CalculatedUserID
    ,ic.[CalculatedUser]
    ,cc.UpdatedUser
    ,cc.UpdatedDate
    ,cc.CreationUser
    ,cc.CreationDate
    ,cc.AssetComplianceStatusID
    ,ISNULL(ic.[HostIdentifyingNumber], cc.[HostIdentifyingNumber]) as [HostIdentifyingNumber]    
    ,ic.[HostID]
    ,ic.[HostType]

    ,ISNULL(ic.[IMEI], md.IMEI) as [IMEI]
    ,ISNULL(ic.[PhoneNumber], md.PhoneNo) as [PhoneNo]
    ,ISNULL(ic.[EmailAddress], md.EmailAddress) as [EmailAddress]        
    --
    ,vmes.DefaultValue as [VMEnabledState]
    ,v.AffinityEnabled
    ,v.CPUAffinity
    ,v.CoreAffinity
    ,v.VMLocation
    ,vmt.DefaultValue as [VMType]
    ,vmpt.[DefaultValue] as [PoolType]
    ,vmp.[PoolName]
    --
    ,ast.AssetTypeName
    ,a.AssetTag
    ,st.StatusResourceName
    ,st.StatusDefaultValue
    ,a.Comments
    ,a.DeliveryDate
    ,a.DisposalDate
    ,a.InstallationDate
    ,a.PurchasePrice
    ,a.RequestNo
    ,a.RetirementDate
    ,awt.WarrantyTypeResourceName
    ,awt.WarrantyTypeDefaultValue
    ,a.WarrantyExpirationDate
    ,a.ShortDescription
    ,a.LeaseEndDate
    -- Irrelevant in this context
    ,NULL AS PreExpiryDate
    ,a.ManufacturerPartNo
    ,CASE WHEN a.AssetID IS NULL THEN cccu.UserName ELSE acu.UserName END AS AssignedUser
    ,ExternalComputers.LinkedToComputer
    ,a.SerialNumber
    ,a.PurchasePriceRateID
    ,a.AssetWarrantyTypeID
    ,a.DeletionDate
    ,cdu.QualifiedName AS UserDomain
    ,a.IsLeased
    --,cc.LocationID
    ,l.Path AS Location
    --,cc.BusinessUnitID
    ,d.Path AS Department
    --,cc.CostCenterID  
    ,costc.Path AS CostCenter
    --,cc.CategoryID
    ,cat.Path AS Category
    --
    ,ic.[IncompleteRecord]
    ,ic.[UntrustedSerialNo]
    ,ic.[FullDetailsFromExternalID]
    ,ic.[FullDetailsFromComplianceConnectionID]
    ,ic.[IsRemoteACLDevice]
    ,ic.[IsDuplicate]
    ,ic.[LegacySerialNo]
    ,ic.[LastSuccessfulInventoryDate]
    ,ic.[MDScheduleGeneratedDate]
    ,ic.[MDScheduleContainsPVUScan]
    ,ic.[FirmwareSerialNumber]
    ,ic.[MachineID]
    ,ic.[IgnoredDueToLicense]
    ,ic.[CloudServiceProvider]
    ,ic.[CSPMetadataJsonBlob]
    -- 
  FROM dbo.[ImportedComputer] as ic    
    LEFT OUTER JOIN dbo.ComplianceComputer cc WITH (NOLOCK) ON cc.ComplianceComputerId = ic.ComplianceComputerID
    LEFT OUTER JOIN dbo.ComplianceComputerInventorySourceType i WITH (NOLOCK) ON i.ComplianceComputerInventorySourceTypeID = cc.ComplianceComputerInventorySourceTypeID
    LEFT OUTER JOIN dbo.ComplianceComputerType cct WITH (NOLOCK) ON cct.ComplianceComputerTypeID = cc.ComplianceComputerTypeID
    LEFT OUTER JOIN dbo.ComputerChassisTypeI18N AS ccht WITH (NOLOCK) ON ccht.ChassisTypeID = cc.ChassisTypeID
    LEFT OUTER JOIN dbo.ComputerChassisTypeI18N AS accht WITH (NOLOCK) ON accht.ChassisTypeID = cc.AssignedChassisTypeID
    LEFT OUTER JOIN dbo.ComplianceTranslation ctt WITH (NOLOCK) ON ctt.ResourceString = cct.ResourceName
    LEFT OUTER JOIN dbo.ComplianceTranslation cti WITH (NOLOCK) ON cti.ResourceString = i.ResourceName
    LEFT OUTER JOIN dbo.VirtualMachine v WITH (NOLOCK) ON v.ComplianceComputerID = cc.ComplianceComputerID AND v.VMSourceTypeID != 1 -- 'VMSourceType.Manual'
    LEFT OUTER JOIN dbo.[VMTypeI18N] as vmt ON vmt.[VMTypeID] = v.[VMTypeID]
    LEFT OUTER JOIN dbo.[VMEnabledStateI18N] AS vmes ON vmes.[VMEnabledStateID] = v.[VMEnabledStateID]
    LEFT OUTER JOIN dbo.[VMPool] as vmp ON vmp.[VMPoolID] = v.[VMPoolID]
    LEFT OUTER JOIN dbo.[VMPoolTypeI18N] AS vmpt ON vmpt.[VMPoolTypeID] = vmp.[VMPoolTypeID]
  --FROM dbo.ComplianceComputerI18n AS cc WITH (NOLOCK)
    LEFT OUTER JOIN dbo.Asset AS a WITH (NOLOCK) ON cc.AssetID = a.AssetID
    LEFT OUTER JOIN dbo.AssetTypeI18N AS ast on a.AssetTypeID = ast.AssetTypeID
    LEFT OUTER JOIN dbo.AssetStatusI18N AS st on a.AssetStatusID = st.AssetStatusID
    LEFT OUTER JOIN dbo.AssetWarrantyTypeI18N AS awt on a.AssetWarrantyTypeID = awt.AssetWarrantyTypeID
    LEFT OUTER JOIN dbo.ComplianceUser AS acu WITH (NOLOCK) ON acu.ComplianceUserID = a.AssignToUserID
    LEFT OUTER JOIN dbo.ComplianceUser AS cccu WITH (NOLOCK) ON cccu.ComplianceUserID = cc.AssignedUserID
    LEFT OUTER JOIN dbo.Category AS cat ON cat.GroupExID = a.CategoryID
    LEFT OUTER JOIN dbo.Location AS l ON l.GroupExID = a.LocationID
    LEFT OUTER JOIN dbo.CorporateUnit AS d ON d.GroupExID = a.BusinessUnitID
    LEFT OUTER JOIN dbo.CostCenter AS costc ON costc.GroupExID = a.CostCenterID
    LEFT OUTER JOIN dbo.ComplianceDomain AS cdu ON cdu.ComplianceDomainID = cccu.ComplianceDomainID
    LEFT OUTER JOIN dbo.ComplianceDomain AS cdc ON cdc.ComplianceDomainID = cc.ComplianceDomainID
    LEFT OUTER JOIN dbo.MobileDevice md ON md.ComplianceComputerID = cc.ComplianceComputerID
    LEFT OUTER JOIN
    (
      SELECT ComplianceComputerID,
        CASE 
          WHEN ComplianceComputerStatusID <> 4 THEN CONVERT(BIT, 1) 
          ELSE CONVERT(BIT, 0)
          END AS LinkedToComputer
      FROM dbo.ComplianceComputer WITH (NOLOCK)
    ) AS ExternalComputers ON ExternalComputers.ComplianceComputerID = cc.ComplianceComputerID
  WHERE a.AssetID IN (SELECT * FROM TableAssetCurrentUser_WithVMs(NULL, NULL, NULL, NULL))
)
SELECT
  ci.[ExternalID] as [ComputerID],
  --ci.[ComplianceComputerID] as [ComputerID],
  ci.[ComputerName],
  ci.[FlatDomainName] as [DomainFlatName],
  ci.[DomainName] as [DomainQualifiedName],
  ci.[UUID] as [BIOSUUID],
  ci.[OperatingSystem],
  ci.[ServicePack],
  ci.[EmailAddress],
  ci.[PhoneNo] as [PhoneNumber],
  ci.[Manufacturer],
  ci.[ModelNo],
  ci.[SerialNo],
  ci.[ChassisType],
  ci.[TotalMemory],
  ci.[NumberOfDisplayAdapters],
  ci.[VirtualMachineUUID],
  ci.[IMEI],
  ci.[NumberOfProcessors],
  ci.[ProcessorType],
  ci.[MaxClockSpeed],
  ci.[NumberOfCores],
  ci.[NumberOfSockets],
  ci.[NumberOfLogicalProcessors],
  ci.[PartialNumberOfProcessors],
  ci.[NumberOfHardDrives],
  ci.[TotalDiskSpace],
  ci.[NumberOfNetworkCards],
  ci.[IPAddress],
  ci.[MACAddress],
  null as [LastLoggedOnUser],
  null as [LastLogonDate],
  null as [CalculatedUser],
  null as [HostComputerID],
  ci.[VMType] as [VirtualMachineType],
  ci.[VMEnabledState],
  ci.[AffinityEnabled],
  ci.[CPUAffinity],
  ci.[CoreAffinity],
  ci.[ComplianceComputerTypeName] as [ComplianceComputerType],
  ci.[HostIdentifyingNumber],
  null as [HostType],
  ci.[VMLocation],
  ci.[PoolName],
  ci.[PoolType],
  null as [CPUUsage],
  null as [MemoryUsage],
  ci.[InventoryDate],
  null as [ClusterID],
  null as [ClusterNodeType],
  ci.[HostIdentifyingNumber] as [HostID],
  null as [FirmwareSerialNumber],
  null as [MachineID],
  null as [InstanceCloudID],
  null as [CloudServiceProvider],
  null as [InstanceAffinity],
  null as [ImageID],
  null as [LaunchTime],
  null as [NetworkID],
  null as [LifecycleMode],
  null as [Account],
  null as [ThreadsPerCore],
  null as [InstanceType],
  null as [Region],
  null as [AvailabilityZone],
  null as [InstanceTenancy]
FROM ComputerInfo as ci
