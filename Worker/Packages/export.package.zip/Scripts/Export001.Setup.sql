---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export setup
-- Export Number: 1.01
-- Updated: 09/09/2023 12:15
---------------------------------------------------------------------------

USE FNMSStaging

SELECT count(*) FROM Vendors  
