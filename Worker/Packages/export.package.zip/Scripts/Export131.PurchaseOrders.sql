---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export Purchases
-- Export Number: 1.32
-- Updated: 11/09/2023 14:15
---------------------------------------------------------------------------

--USE FNMSCompliance

DECLARE @CurrencyID int
SET @CurrencyID = 1;    

WITH PurchaseOrderInfo AS
(
  SELECT
    po.PurchaseOrderID AS [PurchaseOrderID],
    po.PurchaseOrderNo AS [PurchaseOrderNumber],
    po.ShortDescription AS [PurchaseOrderDescription],    
    pos.DefaultValue AS [PurchaseOrderStatus],
    CAST(po.SalesTax * SalesTaxRate.Rate AS money) AS [SalesTax],
    v.VendorName AS [Vendor],
    po.Comments AS [Comments],
    po.PurchaseOrderDate AS [PurchaseOrderDate],
    po.InvoiceDate AS [InvoiceDate],
    sm.DefaultValue AS [ShippingMethod],
    ShippingLocation.Path AS [ShippingLocation],
    po.ShippingDate AS [ShippingDate],
    po.InvoiceNo AS [InvoiceNo],
    po.UpdatedUser AS [UpdatedUser],
    CorporateStructure.Path AS [CorporateStructure],
    CAST(po.TotalPrice * TotalPriceRate.Rate AS money) AS [TotalPrice],
    ISNULL(NumberOfPurchaseOrderDetailsCount.NumberOfPurchaseOrderDetails, 0) AS [NumberOfPurchaseOrderDetails],
    po.RequestNo AS [RequestNo],
    po.RequestDate AS [RequestDate],
    CostCenter.Path AS [CostCenter],
    Location.Path AS [Location],
    Category.Path AS [Category],
    po.AutoCalculateCostFromChildren AS [AutoCalculateCostFromChildren],
    CAST(po.ShippingAndHandling * ShippingAndHandlingRate.Rate AS money) AS [ShippingAndHandling],
    po.CreationUser AS [CreationUser]
  FROM PurchaseOrder AS po
  	LEFT OUTER JOIN PurchaseOrderStatusI18N AS pos ON pos.PurchaseOrderStatusID = po.PurchaseOrderStatusID
    LEFT OUTER JOIN GetCurrencyExchangeRates(@CurrencyID) AS SalesTaxRate ON SalesTaxRate.CurrencyRateID = po.SalesTaxRateID
    LEFT OUTER JOIN dbo.Vendor AS v ON v.VendorID = po.VendorID
    LEFT OUTER JOIN ShippingMethodI18N AS sm ON sm.ShippingMethodID = po.ShippingMethodID
    LEFT OUTER JOIN GroupEx AS ShippingLocation ON po.ShippingLocationID = ShippingLocation.GroupExID
    LEFT OUTER JOIN GroupEx AS CorporateStructure ON po.BusinessUnitID = CorporateStructure.GroupExID
    LEFT OUTER JOIN GetCurrencyExchangeRates(@CurrencyID) AS TotalPriceRate ON TotalPriceRate.CurrencyRateID = po.TotalPriceRateID
    LEFT OUTER JOIN
    (
      SELECT 
        COUNT(DISTINCT PurchaseOrderDetailInfo.PurchaseOrderDetailID) AS NumberOfPurchaseOrderDetails,
        PurchaseOrderDetailInfo.PurchaseOrderID 
      FROM PurchaseOrderDetail AS PurchaseOrderDetailInfo 
      GROUP BY PurchaseOrderDetailInfo.PurchaseOrderID
    ) AS NumberOfPurchaseOrderDetailsCount ON NumberOfPurchaseOrderDetailsCount.PurchaseOrderID = po.PurchaseOrderID
    LEFT OUTER JOIN GroupEx AS CostCenter ON po.CostCenterID = CostCenter.GroupExID
    LEFT OUTER JOIN GroupEx AS Location ON po.LocationID = Location.GroupExID
    LEFT OUTER JOIN Category AS Category ON po.CategoryID = Category.GroupExID
    LEFT OUTER JOIN GetCurrencyExchangeRates(@CurrencyID) AS ShippingAndHandlingRate ON ShippingAndHandlingRate.CurrencyRateID = po.ShippingAndHandlingRateID
)
SELECT *
FROM PurchaseOrderInfo as poi
ORDER BY poi.PurchaseOrderNumber
