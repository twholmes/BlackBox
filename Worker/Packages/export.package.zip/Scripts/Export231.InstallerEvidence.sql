---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export Installer Evidence records
-- Export Number: 2.31
-- Updated: 14/09/2023 14:15
---------------------------------------------------------------------------

--USE FNMSCompliance

WITH InstallerEvidence AS
(
  SELECT 
    iiie.[ComplianceConnectionID]
    ,iiie.[ExternalComputerID] as [ComputerID]
    ,iiie.[ExternalInstanceID]
    ,iie.[ExternalInstallerID]
    ,null as [InstanceName]    
    ,iie.[DisplayName]
    ,iie.[Version]
    ,iie.[Publisher]
    ,iie.[Evidence]
    ,iie.[ProductCode]
    ,iie.[AccessModeID]
    ,am.[DefaultValue] as [AccessMode]
    --,iiie.[ExternalInstallerEvidenceID]
    ,iiie.[InstallDate]
    ,iiie.[DiscoveryDate]
    ,null as [NumberOfSessions]
    ,null as [StartDate]
    ,null as [LastUsedDate]
    ,null as [UserID]
  FROM dbo.[ImportedInstalledInstallerEvidence] as iiie
    LEFT OUTER JOIN dbo.[ImportedInstallerEvidence] as iie on iie.[ExternalInstallerID] = iiie.[ExternalInstallerEvidenceID] and iie.[ComplianceConnectionID] = iiie.[ComplianceConnectionID]
    LEFT OUTER JOIN dbo.[AccessModeI18N] as am on am.[AccessModeID] = iie.[AccessModeID]
)
SELECT
  ie.ComputerID
  ,ie.InstanceName
  ,ie.DisplayName
  ,ie.Version
  ,ie.Publisher
  ,ie.Evidence
  ,ie.ProductCode
  ,ie.AccessMode
  ,ie.InstallDate
  ,ie.DiscoveryDate
  ,ie.NumberOfSessions
  ,ie.StartDate
  ,ie.LastUsedDate
  ,ie.UserID
FROM InstallerEvidence as ie
WHERE ie.ComplianceConnectionID = 3

