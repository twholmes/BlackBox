---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export Installer Evidence records
-- Export Number: 2.41
-- Updated: 14/09/2023 14:15
---------------------------------------------------------------------------

--USE FNMSCompliance

WITH FileEvidence AS
(
  SELECT 
    ife.[ComplianceConnectionID]
    ,iife.[ExternalID] AS [ComputerID]
    ,ife.[ExternalFileID]
    ,ife.[FileName]
    ,ife.[FileVersion]
    ,ife.[ProductVersion]
    ,ife.[ProductName]
    ,ife.[FilePath]
    ,ife.[Company]
    ,ife.[Description]
    ,ife.[FileSize]
    ,ife.[Language]
    ,ife.[AccessModeID]
    ,am.[DefaultValue] as [AccessMode]    
    ,null as [NumberOfSessions]
    ,null as [StartDate]
    ,null as [LastUsedDate]
    ,null as [UserID]
  FROM dbo.[ImportedInstalledFileEvidence] as iife
    INNER JOIN dbo.[ImportedFileEvidence] as ife on ife.[ExternalFileID] = iife.[ExternalFileID] and ife.[ComplianceConnectionID] = iife.[ComplianceConnectionID]
    LEFT OUTER JOIN dbo.[AccessModeI18N] as am on am.[AccessModeID] = ife.[AccessModeID]    
)
SELECT
  fe.ComputerID
  ,fe.FileName
  ,fe.FileVersion
  ,fe.ProductVersion
  ,fe.ProductName
  ,fe.FilePath
  ,fe.Company
  ,fe.Description
  ,fe.FileSize
  ,fe.Language
  ,fe.AccessMode
  ,fe.NumberOfSessions
  ,fe.StartDate
  ,fe.LastUsedDate
  ,fe.UserID
FROM FileEvidence as fe
WHERE fe.ComplianceConnectionID = 3

