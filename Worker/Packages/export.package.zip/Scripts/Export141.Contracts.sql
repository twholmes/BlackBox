---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export Contracts
-- Export Number: 1.41
-- Updated: 11/09/2023 14:15
---------------------------------------------------------------------------

--USE FNMSCompliance
                                      
DECLARE @CurrencyID int               
SET @CurrencyID = 1;                  

WITH ContractInfo AS                  
(                                     
  SELECT  
    --c.ContractID AS [ContractID
    c.ContractNo AS [ContractNumber]
    ,c.ContractName AS [ContractName]
    ,v.VendorName AS [Vendor]
    --,c2v.[VendorID]
    --,c2v.[VendorName]
    ,ct.ContractTypeDefaultValue AS [ContractType]
    --,cs.DefaultValue AS [ContractState]
    ,csn.DefaultValue AS [ContractStatus]
    ,c.NeverExpires AS [NeverExpires]
    ,c.StartDate AS [StartDate]
    ,c.PreExpiryDate AS [PreExpiryDate]  
    ,c.RenewalDate AS [RenewalDate]  
    ,c.EndDate AS [EndDate]
    ,DateDiff (Day, GetDate(), CAST (c.EndDate as date)) AS [DaysUntilEnd]
    ,c.MasterContractID AS [MasterContractID]
    ,mc.ContractName AS [MasterContractName]
    ,mc.ContractNo AS [MasterContractNumber]
    ,mct.ContractTypeDefaultValue AS [MasterContractType]
    ,c.PreviousContractID AS [PreviousContractID]
    ,cprev.ContractName AS [Previous Contract]
    ,(SELECT ContractName FROM dbo.GetReplacementContractName(c.ContractID)) AS [ReplacementContractName]
    ,Location.Path AS [Location]
    ,CorporateStructure.Path AS [CorporateStructure]
    ,CostCenter.Path AS [CostCenter]
    ,Category.Path AS [Category]
    ,c.UseHostProcessorInformation AS [UseHostProcessorInformation]
    ,c.CoverInstallsOnVirtualMachines AS [CoverInstallsOnVirtualMachines]
    ,c.LicenseDowngradeToEdition AS [LicenseDowngradeToEdition]
    ,c.LicenseDowngradeToVersion AS [LicenseDowngradeToVersion]
    ,c.LicenseDowngradeEnabled AS [LicenseDowngradeEnabled]
    ,c.GrantLimitPointsToLicense AS [GrantLimitPointsToLicense]
    ,c.GrantSecondUseToLicense AS [GrantSecondUseToLicense]
    ,c.LicenseUpgradeEnabled AS [LicenseUpgradeEnabled]
    ,c.GrantVirtualInstallsToLicense AS [GrantVirtualInstallsToLicense]
    ,c.LimitNumberOfComputersUserLicenseCanBeInstalledOn AS [LimitNumberOfComputersUserLicenseCanBeInstalledOn]
    ,c.LimitNumberOfVirtualInstalls AS [LimitNumberOfVirtualInstalls]
    ,c.LimitVirtualInstallsIncludesHost AS [LimitVirtualInstallsIncludesHost] 
    ,c.InitialPlatformQuantity AS [MsEaInitialPlatformQuantity]
    ,MSSelectApplicationLevel.DefaultValue AS [MSSelectApplicationLevel]
    ,MSSelectServerLevel.DefaultValue AS [MSSelectServerLevel]
    ,MSSelectSystemLevel.DefaultValue AS [MSSelectSystemLevel]
    ,Project.ProjectName AS [ProjectName]
    ,pp.Name AS [PurchaseProgram]
    ,c.SecondUsageAtHome AS [SecondUsageAtHome]
    ,c.SecondUsageWorkLaptop AS [SecondUsageWorkLaptop]
    ,CAST(c.TotalValue * TotalValueRate.Rate AS money) AS [TotalValue]
    ,c.LicenseUpgradeToVersion AS [LicenseUpgradeToVersion]
    ,c.LicenseUpgradeUntilContractExpiry AS [LicenseUpgradeUntilContractExpiry]
    ,LocationLast.GroupName AS [LocationLast]
    ,c.NumberOfAllowedVirtualInstalls AS [NumberOfAllowedVirtualInstalls]
    ,c.MonthlyValue AS [Monthly amount]
    ,c.LastRenewedDate AS [Last renewed date]
    ,c.TotalValue AS [Global amount]
    ,ISNULL(NumberOfChildContractsCount.NumberOfChildContracts, 0) AS [NumberOfChildContracts] 
    ,c.LimitNumberOfApplicationsEachLicensePointCovers AS [LimitNumberOfApplicationsEachLicensePointCovers]
    ,ISNULL(NumberOfPurchaseOrdersCount.NumberOfPurchaseOrders, 0) AS [NumberOfPurchaseOrders]
    ,ISNULL(NumberOfPurchaseOrderDetailsCount.NumberOfPurchaseOrderDetails, 0) AS [NumberOfPurchaseOrderDetails]
    ,ISNULL(NumberOfAssetsCount.NumberOfAssets, 0) AS [NumberOfAssets]  
    ,ISNULL(NumberOfLicensesCount.NumberOfLicenses, 0) AS [NumberOfLicenses]  
    ,c.NumberOfApplicationInstallsAllowedPerLicensePoint AS [NumberOfApplicationInstallsAllowedPerLicensePoint]
    ,c.NumberOfComputersAllowedPerUserLicensePoint AS [NumberOfComputersAllowedPerUserLicensePoint]
    ,c.Comments AS [Comments]
  FROM Contract AS c
  	LEFT OUTER JOIN Category AS Category ON c.CategoryID = Category.GroupExID
    LEFT OUTER JOIN 
    (
      SELECT 
        COUNT(DISTINCT ac.AssetID) AS NumberOfAssets
        ,ac.ContractID 
      FROM AssetContract AS ac 
      GROUP BY ac.ContractID
    ) AS NumberOfAssetsCount ON NumberOfAssetsCount.ContractID = c.ContractID
    LEFT OUTER JOIN 
    (
      SELECT 
        COUNT(DISTINCT mcc.ContractID) AS NumberOfChildContracts
        ,mcc.MasterContractID 
      FROM Contract AS mcc 
      GROUP BY mcc.MasterContractID
    ) AS NumberOfChildContractsCount ON NumberOfChildContractsCount.MasterContractID = c.ContractID
    LEFT OUTER JOIN dbo.ContractTypeI18N AS ct ON ct.ContractTypeID = c.ContractTypeID
    LEFT OUTER JOIN GroupEx AS CorporateStructure ON c.BusinessUnitID = CorporateStructure.GroupExID
    LEFT OUTER JOIN GroupEx AS CostCenter ON c.CostCenterID = CostCenter.GroupExID
    LEFT OUTER JOIN 
    (
      SELECT 
        COUNT(DISTINCT slc.SoftwareLicenseID) AS NumberOfLicenses
        ,slc.ContractID 
      FROM SoftwareLicenseContract AS slc 
      GROUP BY slc.ContractID
    ) AS NumberOfLicensesCount ON NumberOfLicensesCount.ContractID = c.ContractID
    LEFT OUTER JOIN GroupEx AS Location ON c.LocationID = Location.GroupExID
    LEFT OUTER JOIN [Contract] AS mc ON mc.ContractID = c.MasterContractID
    LEFT OUTER JOIN dbo.Contract AS mc2 ON c.MasterContractID = mc2.ContractID 
    LEFT OUTER JOIN dbo.ContractTypeI18N AS mct ON mct.ContractTypeID = mc2.ContractTypeID
    LEFT OUTER JOIN MSSelectLevelI18N AS MSSelectApplicationLevel ON MSSelectApplicationLevel.MSSelectLevelID = c.MSSelectApplicationLevelID
    LEFT OUTER JOIN MSSelectLevelI18N AS MSSelectServerLevel ON MSSelectServerLevel.MSSelectLevelID = c.MSSelectServerLevelID
    LEFT OUTER JOIN MSSelectLevelI18N AS MSSelectSystemLevel ON MSSelectSystemLevel.MSSelectLevelID = c.MSSelectSystemLevelID
    LEFT OUTER JOIN Project ON Project.ProjectID = c.ProjectID
    LEFT OUTER JOIN 
    (
      SELECT 
        COUNT(DISTINCT PurchaseOrder.PurchaseOrderID) AS NumberOfPurchaseOrders
        ,PurchaseOrder.ContractID 
      FROM PurchaseOrder 
      GROUP BY PurchaseOrder.ContractID
    ) AS NumberOfPurchaseOrdersCount ON NumberOfPurchaseOrdersCount.ContractID = c.ContractID
    LEFT OUTER JOIN PurchaseProgram AS pp ON pp.PurchaseProgramID = c.PurchaseProgramID
    LEFT OUTER JOIN 
    (
      SELECT 
        COUNT(DISTINCT PurchaseOrderDetailInfo.PurchaseOrderDetailID) AS NumberOfPurchaseOrderDetails
        ,PurchaseOrderDetailInfo.PODetailContractID 
      FROM PurchaseOrderDetailInfo AS PurchaseOrderDetailInfo 
      GROUP BY PurchaseOrderDetailInfo.PODetailContractID
    ) AS NumberOfPurchaseOrderDetailsCount ON NumberOfPurchaseOrderDetailsCount.PODetailContractID = c.ContractID
    LEFT OUTER JOIN ContractState AS cs ON cs.ContractStateID = c.ContractStateID
    LEFT OUTER JOIN dbo.ContractStatusI18N AS csn ON csn.ContractStatusID = c.ContractStatusID
    LEFT OUTER JOIN GetCurrencyExchangeRates(@CurrencyID) AS TotalValueRate ON TotalValueRate.CurrencyRateID = c.TotalValueRateID
    LEFT OUTER JOIN dbo.Vendor AS v ON v.VendorID = c.VendorID
    LEFT OUTER JOIN TableGroupExByLevel(1, NULL) AS LocationLast ON c.LocationID = LocationLast.GroupExID
    LEFT OUTER JOIN Contract AS cprev ON c.PreviousContractID = cprev.ContractID
    -- Link from Contract to Vendor
  	LEFT OUTER JOIN 
  	(
      -- Custom view query for vendors
    	SELECT
    	  Vendor.VendorID AS [VendorID],
    		Vendor.VendorName AS [VendorName]
    	FROM Vendor
  	) AS c2v ON c2v.VendorID = c.VendorID 
  )
SELECT *
FROM ContractInfo as ci
ORDER BY ci.ContractNumber
  
  