---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export Currency Rates
-- Export Number: 1.61
-- Updated: 22/09/2023 10:00
---------------------------------------------------------------------------

--USE FNMSCompliance

SELECT 
  [CurrencyRateID]
  ,[CurrencyID]
  ,[SnapshotID]
  ,[Rate]
  ,[CurrencyName]
  ,[CurrencyResourceID]
  ,[CurrencyCode]
  ,[LongPrefix]
  ,[LongSuffix]
  ,[LongFormat]
  ,[ShortPrefix]
  ,[ShortSuffix]
  ,[ShortFormat]
  ,[IsActive]
  ,[SnapshotName]
  ,[SnapshotResourceID]
  ,[SnapshotDate]
  ,[IsStandardRateSnapshot]
  ,[SnapshotReferenceCurrencyID]
  ,[IsDefault]
  ,[RetirementDate]
FROM [dbo].[CurrencyRateInfo]
  