---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export Vendors
-- Export Number: 1.11
-- Updated: 11/09/2023 14:15
---------------------------------------------------------------------------

--USE FNMSCompliance

SELECT
  [VendorID]
  ,[VendorName]
  ,[VendorPreviousName]
  ,[BusinessPhoneNumber] as [PhoneNo]
  ,[FaxPhoneNumber] as [FaxNo]
  ,[Address_Street] as [AddressStreet]
  ,[Address_City] as [AddressCity]
  ,[Address_State] as [AddressState]
  ,[Address_ZIP] as [AddressZip]
  ,[Address_Country] as [AddressCountry]
  --,[Address2_Street]
  --,[Address2_City]
  --,[Address2_State]
  --,[Address2_ZIP]
  --,[Address2_Country]
  ,[WebSite]
  ,[Email]
  ,[ParentVendorID]
  ,[CreationUser]
  ,[CreationDate]
  ,[UpdatedUser]
  ,[UpdatedDate]
  ,[AutomaticallyAcceptPurchases]
FROM [dbo].[Vendor]
