---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export Purchases
-- Export Number: 1.32
-- Updated: 11/09/2023 14:15
---------------------------------------------------------------------------

--USE FNMSCompliance

DECLARE @CurrencyID int
SET @CurrencyID = 1;    

WITH PurchaseInfo AS
(
  SELECT  
    podi.PurchaseOrderDetailID AS [PurchaseOrderLineID]
    ,podi.PurchaseOrderID AS [PurchaseOrderID]
    ,podi.PurchaseOrderNo AS [PurchaseOrderNumber]    
    ,'#'+ podi.PurchaseOrderNo AS [HashPurchaseOrderNumber]
    ,podi.PurchaseOrderDate AS [PurchaseOrderDate]
    ,podi.SequenceNumber AS [SequenceNumber]
    ,podi.ItemDescription AS [Description]
    ,v.VendorName AS [Publisher]
    ,podt.DefaultValue AS [PurchaseOrderDetailType]
    ,podi.Quantity AS [Quantity]
    ,CAST(podi.UnitPrice * UnitPriceRate.Rate AS money) AS [UnitPrice]  
    ,podi.LicensePartNo AS [LicensePartNo]
    ,podi.LicenseQuantity AS [LicenseQuantity]
    ,podi.EffectiveQuantity AS [EffectiveQuantity]
    ,podi.PODetailEffectiveDate AS [PODetailEffectiveDate] 
    ,TablePODAvailableEffectiveQuantity.AvailableEffectiveQuantity AS [AvailableQuantity]
    ,podi.PODetailExpiryDate AS [PODetailExpiryDate]
    ,DateDiff (Day, GetDate(), CAST (podi.PODetailExpiryDate as date)) AS [DaysUntilExpiry]
    ,CAST(podi.PODetailSalesTax * SalesTaxRate.Rate AS money) AS [SalesTax]
    ,CAST(podi.PODetailShippingAndHandling * ShippingAndHandlingRate.Rate AS money) AS [ShippingAndHandling]
    ,podi.PODetailShippingDate AS [ShippingDate]
    ,ShippingLocation.Path AS [ShippingLocation]
    ,ShippingMethodI18N.DefaultValue AS [ShippingMethod]
    ,CAST(podi.PODetailTotalPrice * TotalPriceRate.Rate AS money) AS [TotalPrice]
    ,podi.CreationDate AS [CreationDate]
    ,podi.PODetailRequestDate AS [RequestDate]
    ,podi.PODetailRequestNo AS [RequestNo]
    ,podi.PODetailInvoiceDate AS [InvoiceDate]
    ,podi.PODetailInvoiceNo AS [InvoiceNo]
    ,[BusinessOwnerV].PropertyValue AS [BusinessOwner]
    ,MSSelectPoolI18N.DefaultValue AS [MSSelectPool]
    ,podi.PODetailMSSelectPoints AS [MSSelectPoints]
    ,pod2c.[ContractID]
    ,pod2c.[ContractNumber]
    ,pod2c.[ContractType]
    ,pod2c.[MasterContractID]
    ,ISNULL(NumberOfAssetsCount.NumberOfAssets, 0) AS [NumberOfAssets]
    ,ISNULL(NumberOfLicensesCount.NumberOfLicenses, 0) AS [NumberOfLicenses]
    ,pods.DefaultValue AS [PurchaseOrderStatus] 
    ,podi.ShortDescription AS [PurchaseOrderDescription] 
    ,Location.Path AS [Location]
    ,CostCenter.Path AS [CostCenter]
    ,CorporateStructure.Path AS [CorporateStructure]  
    ,Category.Path AS [Category]
    ,podi.PODetailComments AS [Comments]  
  FROM PurchaseOrderDetailWithPONoSKUMatching AS podi
    CROSS APPLY dbo.TablePurchaseOrderDetailAvailableEffectiveQuantity(podi.PurchaseOrderDetailID, podi.EffectiveQuantity) AS TablePODAvailableEffectiveQuantity
    LEFT OUTER JOIN 
    (
      SELECT 
        COUNT(DISTINCT apo.AssetID) AS NumberOfAssets
        ,apo.PurchaseOrderDetailID 
      FROM AssetPurchaseOrder AS apo
      GROUP BY apo.PurchaseOrderDetailID
    ) AS NumberOfAssetsCount ON NumberOfAssetsCount.PurchaseOrderDetailID = podi.PurchaseOrderDetailID
    LEFT OUTER JOIN dbo.PurchaseOrderDetailProperty [BusinessOwnerT] ON ([BusinessOwnerT].PropertyName = 'BusinessOwner')
    LEFT OUTER JOIN dbo.PurchaseOrderDetailPropertyValue [BusinessOwnerV] ON ([BusinessOwnerV].PurchaseOrderDetailID = podi.PurchaseOrderDetailID AND [BusinessOwnerV].PurchaseOrderDetailPropertyID = [BusinessOwnerT].PurchaseOrderDetailPropertyID)
    LEFT OUTER JOIN Category AS Category ON podi.PODetailCategoryID = Category.GroupExID
    LEFT OUTER JOIN GroupEx AS CorporateStructure ON podi.PODetailBusinessUnitID = CorporateStructure.GroupExID
    LEFT OUTER JOIN GroupEx AS CostCenter ON podi.PODetailCostCenterID = CostCenter.GroupExID
    LEFT OUTER JOIN 
    (
      SELECT 
        COUNT(DISTINCT eta.SoftwareLicenseID) AS NumberOfLicenses
        ,eta.PurchaseOrderDetailID 
      FROM EntitlementTransactionAccepted AS eta
      GROUP BY eta.PurchaseOrderDetailID
    ) AS NumberOfLicensesCount ON NumberOfLicensesCount.PurchaseOrderDetailID = podi.PurchaseOrderDetailID
    LEFT OUTER JOIN GroupEx AS Location ON podi.PODetailLocationID = Location.GroupExID
    LEFT OUTER JOIN dbo.Vendor AS v ON v.VendorID = podi.PublisherID
    LEFT OUTER JOIN MSSelectPoolI18N ON MSSelectPoolI18N.MSSelectPoolID = podi.PODetailMSSelectPoolID
    LEFT OUTER JOIN PurchaseOrder AS po ON po.PurchaseOrderID = podi.PurchaseOrderID
    LEFT OUTER JOIN PurchaseOrderDetailTypeI18N AS podt ON podt.PurchaseOrderDetailTypeID = podi.PurchaseOrderDetailTypeID
    LEFT OUTER JOIN GetCurrencyExchangeRates(@CurrencyID) AS SalesTaxRate ON SalesTaxRate.CurrencyRateID = podi.PODetailSalesTaxRateID
    LEFT OUTER JOIN GetCurrencyExchangeRates(@CurrencyID) AS ShippingAndHandlingRate ON ShippingAndHandlingRate.CurrencyRateID = podi.PODetailShippingAndHandlingRateID
    LEFT OUTER JOIN GroupEx AS ShippingLocation ON podi.PODetailShippingLocationID = ShippingLocation.GroupExID
    LEFT OUTER JOIN ShippingMethodI18N ON ShippingMethodI18N.ShippingMethodID = podi.PODetailShippingMethodID
    LEFT OUTER JOIN PurchaseOrderDetailStatusI18N AS pods ON pods.PurchaseOrderDetailStatusID = podi.PurchaseOrderDetailStatusID
    LEFT OUTER JOIN GetCurrencyExchangeRates(@CurrencyID) AS TotalPriceRate ON TotalPriceRate.CurrencyRateID = podi.PODetailTotalPriceRateID
    LEFT OUTER JOIN GetCurrencyExchangeRates(@CurrencyID) AS UnitPriceRate ON UnitPriceRate.CurrencyRateID = podi.UnitPriceRateID
    -- Link from PurchaseOrderDetail to Contract
    LEFT OUTER JOIN 
    (
      -- Custom view query for contracts
      SELECT
        cx.ContractID AS [ContractID],
        cx.ContractNo AS [ContractNumber],
        ctx.ContractTypeDefaultValue AS [ContractType],
        cx.MasterContractID AS [MasterContractID]
      FROM Contract AS cx
        LEFT OUTER JOIN dbo.ContractTypeI18N AS ctx ON ctx.ContractTypeID = cx.ContractTypeID
    ) AS pod2c ON pod2c.ContractID = podi.PODetailContractID
  )
SELECT *
FROM PurchaseInfo as pi
ORDER BY PurchaseOrderNumber, SequenceNumber
