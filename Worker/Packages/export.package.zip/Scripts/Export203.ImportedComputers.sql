---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export Imported Computers
-- Export Number: 2.03
-- Updated: 12/09/2023 14:15
---------------------------------------------------------------------------

--USE FNMSCompliance

WITH ComputerInfo AS
(
  SELECT 
    ic.[ComplianceConnectionID]
    ,ic.[ExternalID]
    ,ic.[ComplianceComputerID]
    ,ic.[ComplianceComputerTypeID]
    ,ic.[ComputerName]
    ,ic.[ComplianceDomainID]
    ,ic.[Domain]
    ,ic.[OperatingSystem]
    ,ic.[ServicePack]
    ,ic.[NumberOfProcessors]
    ,ic.[ProcessorType]
    ,ic.[MaxClockSpeed]
    ,ic.[NumberOfCores]
    ,ic.[TotalMemory]
    ,ic.[ChassisType]
    ,ic.[NumberOfHardDrives]
    ,ic.[TotalDiskSpace]
    ,ic.[NumberOfNetworkCards]
    ,ic.[NumberOfDisplayAdapters]
    ,ic.[IPAddress]
    ,ic.[MACAddress]
    ,ic.[Manufacturer]
    ,ic.[ModelNo]
    ,ic.[SerialNo]
    ,ic.[HostID]
    ,ic.[LastLoggedOnUser]
    ,ic.[InventoryDate]
    ,ic.[HardwareInventoryDate]
    ,ic.[ServicesInventoryDate]
    ,ic.[InventoryAgent]
    ,ic.[IncompleteRecord]
    ,ic.[NumberOfSockets]
    ,ic.[PartialNumberOfProcessors]
    ,ic.[UntrustedSerialNo]
    ,ic.[FullDetailsFromExternalID]
    ,ic.[FullDetailsFromComplianceConnectionID]
    ,ic.[ILMTAgentID]
    ,ic.[FNMPComputerUID]
    ,ic.[HostIdentifyingNumber]
    ,ic.[HostType]
    ,ic.[NumberOfLogicalProcessors]
    ,ic.[IsRemoteACLDevice]
    ,ic.[IsDuplicate]
    ,ic.[LegacySerialNo]
    ,ic.[UUID]
    ,ic.[IMEI]
    ,ic.[PhoneNumber]
    ,ic.[EmailAddress]
    ,ic.[CalculatedUser]
    ,ic.[LastSuccessfulInventoryDate]
    ,ic.[MDScheduleGeneratedDate]
    ,ic.[MDScheduleContainsPVUScan]
    ,ic.[FirmwareSerialNumber]
    ,ic.[MachineID]
    ,ic.[IgnoredDueToLicense]
    ,ic.[CloudServiceProvider]
    ,ic.[CSPMetadataJsonBlob]
    ,ic.[AgentVersion]
  FROM [dbo].[ImportedComputer] as ic

)
SELECT *.ci
FROM ComputerInfo as ci
