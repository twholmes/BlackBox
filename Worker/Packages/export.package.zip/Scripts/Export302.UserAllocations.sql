---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export UserAllocations
-- Export Number: 2.03
-- Updated: 3/12/2023 17:00
---------------------------------------------------------------------------

--USE FNMSCompliance

WITH UserAllocations AS
(
  -- UserAllocationsExport: Custom view query for software license allocations 
  SELECT  
    sla.SoftwareLicenseAllocationID AS [SoftwareLicenseAllocationID]
    ,sl.Name AS [LicenseName]
    ,sl.Version AS [LicenseVersion]
    ,cu.UserName AS [UserName]
    ,ISNULL(au.Email, acau.Email) AS [EndUserEmail]
    ,slau.SoftwareLicenseAllocationUserTypeDefaultValue AS [UserType]
    ,sla.NumberAllocated AS [NumberAllocated]
    ,slas.StatusDefaultValue AS [AllocationStatus]
    ,sla.AllocationReason AS [AllocationReason]
    ,sler.ExemptionReason AS [ExemptionReason]
    ,slk.KeyValue AS [LicenseKey]
    ,ISNULL(au.UserName, acau.UserName) AS [RelatedEndUser]
    --,slas.StatusDefaultValue AS [Status]
    --,cc.ComputerName AS [ComputerName]
  FROM SoftwareLicenseAllocation AS sla
    LEFT OUTER JOIN dbo.SoftwareLicense AS sl ON sl.SoftwareLicenseID = sla.SoftwareLicenseID
    LEFT OUTER JOIN dbo.ComplianceComputer AS cc ON cc.ComplianceComputerID = sla.ComplianceComputerID
    LEFT OUTER JOIN dbo.ComplianceUser AS cu ON cu.ComplianceUserID = sla.ComplianceUserID
    LEFT OUTER JOIN dbo.SoftwareLicenseExemptionReasonInfo AS sler ON sler.SoftwareLicenseExemptionReasonID = sla.SoftwareLicenseExemptionReasonID
    LEFT OUTER JOIN dbo.SoftwareLicenseAllocationStatusI18N AS slas ON slas.SoftwareLicenseAllocationStatusID = sla.SoftwareLicenseAllocationStatusID
    LEFT OUTER JOIN dbo.ComplianceComputer AS ac ON (sla.ComplianceComputerID = ac.ComplianceComputerID) 
    LEFT OUTER JOIN dbo.ComplianceUser AS acau ON (ac.AssignedUserID = acau.ComplianceUserID) 
    LEFT OUTER JOIN dbo.ComplianceUser AS au ON (sla.ComplianceUserID = au.ComplianceUserID)
    LEFT OUTER JOIN dbo.SoftwareLicenseAllocationUserTypeI18N AS slau ON slau.SoftwareLicenseAllocationUserTypeID = sla.SoftwareLicenseAllocationUserTypeID
    LEFT OUTER JOIN dbo.SoftwareLicenseKey AS slk ON slk.SoftwareLicenseKeyID = sla.SoftwareLicenseKeyID
)
SELECT ua.*
FROM UserAllocations as ua
