---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export DeviceAllocations
-- Export Number: 2.03
-- Updated: 3/12/2023 17:00
---------------------------------------------------------------------------

--USE FNMSCompliance

WITH DeviceAllocations AS
(
  -- DeviceAllocationsExport: Custom view query for software license allocations
  SELECT  
    sla.SoftwareLicenseAllocationID AS [SoftwareLicenseAllocationID]
    ,sl.Name AS [LicenseName]
    ,sl.Version AS [LicenseVersion]
    ,a2c.[ComputerID]
    ,cc.ComputerName AS [ComputerName]
    ,a2c.[ComputerType]
    ,sla.NumberAllocated AS [NumberAllocated]
    ,slas.StatusDefaultValue AS [AllocationStatus]
    ,sla.AllocationReason AS [AllocationReason]
    ,sler.ExemptionReason AS [ExemptionReason]
    ,a2c.[InventorySourceType]
    ,slk.KeyValue AS [LicenseKey]
    --,a2c.[ComputerName]
    --,cu.UserName AS [UserName]
  FROM dbo.SoftwareLicenseAllocation as sla
    LEFT OUTER JOIN dbo.ComplianceComputer AS cc ON cc.ComplianceComputerID = sla.ComplianceComputerID
    LEFT OUTER JOIN dbo.SoftwareLicense AS sl ON sl.SoftwareLicenseID = sla.SoftwareLicenseID
    LEFT OUTER JOIN dbo.ComplianceUser AS cu ON cu.ComplianceUserID = sla.ComplianceUserID
    LEFT OUTER JOIN dbo.SoftwareLicenseAllocationStatusI18N AS slas ON slas.SoftwareLicenseAllocationStatusID = sla.SoftwareLicenseAllocationStatusID
    LEFT OUTER JOIN dbo.SoftwareLicenseKey AS slk ON slk.SoftwareLicenseKeyID = sla.SoftwareLicenseKeyID
    LEFT OUTER JOIN dbo.SoftwareLicenseExemptionReasonInfo AS sler ON sler.SoftwareLicenseExemptionReasonID = sla.SoftwareLicenseExemptionReasonID
    -- Link from SoftwareLicenseAllocation to Allocated Computer
    LEFT OUTER JOIN 
    (
      -- Custom view query for computers
      SELECT  
        ccx.ComplianceComputerID AS [ComputerID]
        ,ccx.ComputerName AS [ComputerName]
        ,cct.DefaultValue AS [ComputerType]
        ,ccst.DefaultValue AS [InventorySourceType]
      FROM dbo.ComplianceComputerWithActiveInventory AS ccx
        LEFT OUTER JOIN dbo.ComplianceComputerTypeI18N AS cct ON cct.ComplianceComputerTypeID = ccx.ComplianceComputerTypeID
        LEFT OUTER JOIN dbo.ComplianceComputerInventorySourceTypeI18N AS ccst ON ccst.ComplianceComputerInventorySourceTypeID = ccx.ComplianceComputerInventorySourceTypeID
    ) AS a2c ON a2c.ComputerID = sla.ComplianceComputerID
)
SELECT da.*
FROM DeviceAllocations as da
