---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export Licenses
-- Export Number: 1.51
-- Updated: 11/09/2023 14:15
---------------------------------------------------------------------------

--USE FNMSCompliance
                                      
DECLARE @CurrencyID int               
SET @CurrencyID = 1;                  

WITH LicenseInfo AS                  
(                                     
  SELECT  
    SoftwareLicense.SoftwareLicenseID AS [SoftwareLicenseID]
    ,SoftwareLicense.Name AS [Name]
    ,SoftwareLicense.[Edition] AS [Edition]        
    ,SoftwareLicense.[Version] AS [Version]
    ,SoftwareLicenseTypeI18N.TypeDefaultValue AS [LicenseType]
    ,Vendor.VendorName AS [VendorName]
    ,Publisher.VendorName AS [PublisherName]
    ,ProductPrimary.ProductName AS [ProductName]
    ,LicenseStatusI18N.DefaultValue AS [LicenseStatus]    
    ,AcquisitionModeI18N.DefaultValue AS [AcquisitionMode]
    ,SoftwareLicenseUseRight.PURLComment AS [PURLComment]
    ,SoftwareLicense.AdditionalBulkUsersInfrequent AS [AdditionalBulkUsersInfrequent]
    ,SoftwareLicense.AdditionalBulkUsersExternal AS [AdditionalBulkUsersExternal]
    ,SoftwareLicense.AdditionalBulkUsersRegular AS [AdditionalBulkUsersRegular]
    ,SoftwareLicenseUseRight.AllowExternalRoamingUse AS [AllowExternalRoamingUse]
    ,SoftwareLicense.AlwaysInstalled AS [AlwaysInstalled]
    ,SoftwareLicense.LimitNumberOfApplicationsEachLicensePointCovers AS [LimitNumberOfApplicationsEachLicensePointCovers]
    ,ISNULL(GroupAssignedTotals.NumberAllocated, 0) AS [NumberAssigned]
    ,SoftwareLicense.MinimumNumberOfUsersMultipliedByProcessors AS [MinimumNumberOfUsersMultipliedByProcessors]
    ,Category.Path AS [Category]
    ,SoftwareLicense.NumberCalculated AS [NumberCalculated]
    ,CorporateStructure.Path AS [CorporateStructure]
    ,CostCenter.Path AS [CostCenter]
    ,SoftwareLicense.DeliveryDate AS [DeliveryDate]
    ,DowngradetoVersion.DowngradeToVersion AS [DowngradeToVersion]
    ,DowngradeEnabled.DowngradeEnabled AS [DowngradeEnabled]
    ,DowngradeToEditionName.EditionName AS [DowngradeToEditionName]
    ,DowngradeToVersionName.VersionName AS [DowngradeToVersionName]
    ,SoftwareLicenseDurationI18N.DurationDefaultValue AS [Duration]
    ,SoftwareLicenseUseRight.LicenseMobilityApplies AS [LicenseMobilityApplies]
    ,sls.EntitlementLimitString AS [EntitlementLimitString]
    ,SoftwareLicense.ExpiryDate AS [ExpiryDate]
    ,CAST(CAST(SoftwareLicense.UserMultiplierExternal AS DECIMAL(38, 5)) AS NVARCHAR) AS [UserMultiplierExternal]
    ,CAST(CASE WHEN (ISNULL(smt.NumberMaintained,0) > 0) THEN 1 ELSE 0 END AS BIT) AS [HasActiveMaintenance]
    ,CAST(CAST(SoftwareLicense.UserMultiplierInfrequent AS DECIMAL(38, 5)) AS NVARCHAR) AS [UserMultiplierInfrequent]
    ,SoftwareLicenseComplianceStatusI18N.StatusDefaultValue AS [LicenseCompliance]
    ,DowngradeToEdition.DowngradeToEdition AS [DowngradeToEdition]
    ,SoftwareLicenseKeyTypeI18N.KeyTypeDefaultValue AS [LicenseKeyType]
    ,SoftwareLicenseMetricI18N.DefaultValue AS [Metric]
    ,SoftwareLicense.LastCalculatedNUPMinimum AS [LastCalculatedNUPMinimum]
    ,SoftwareLicense.LimitNumberOfVirtualInstalls AS [LimitNumberOfVirtualInstalls]
    ,Location.Path AS [Location]
    ,SoftwareLicense.LimitVirtualInstallsIncludesHost AS [LimitVirtualInstallsIncludesHost]
    ,SoftwareLicense.LimitNumberOfComputersUserLicenseCanBeInstalledOn AS [LimitNumberOfComputersUserLicenseCanBeInstalledOn]
    ,SoftwareLicense.LicenseKey AS [LicenseKey]
    ,ComplianceUser.UserName AS [ManagerName]
    ,SoftwareLicenseUseRight.ReassignmentTimeLimit AS [ReassignmentTimeLimit]
    ,SoftwareLicenseUseRight.NumberOfProcessorsPerOSE AS [NumberOfProcessorsPerOSE]
    ,SoftwareLicenseUseRight.TotalNumberOfCoresPerVMPerLicense AS [TotalNumberOfCoresPerVMPerLicense]
    ,SoftwareLicense.MinimumNumberOfProcessors AS [MinimumNumberOfProcessors]
    ,SoftwareLicense.MinimumNumberOfUsers AS [MinimumNumberOfUsers]
    ,SoftwareLicense.MSPoints AS [MSPoints]
    ,SoftwareLicense.MSPool AS [MSPool]
    ,SoftwareLicense.AlternateNonInventoriedUsers AS [AlternateNonInventoriedUsers]
    ,SoftwareLicense.NumberAllocated AS [NumberAllocated]
    ,SoftwareLicense.ParentLicenseID AS [ParentLicenseID]
    ,SoftwareLicense.PartNo AS [PartNumber]
    ,SoftwareLicense.PeakConsumed AS [PeakConsumed]
    ,PricePerRight.PricePerRightInDefaultCurrency AS [PricePerRight]
    ,PricePerRightPeriodTypeI18N.PeriodTypeDefaultValue AS [PeriodType]
    ,sltp.CompliancePriority AS [Priority]
    ,SoftwareLicense.NumberOfProcessors AS [NumberOfProcessors]
    ,SoftwareLicense.PurchaseOrderNumber AS [PurchaseOrderNumber]
    ,CAST(SoftwareLicense.PurchasePrice * PurchasePriceRate.Rate AS money) AS [PurchasePrice]
    ,SoftwareLicense.PurchaseOrderDate AS [PurchaseOrderDate]
    ,SoftwareLicenseUseRightIBM.PVULimit AS [PVULimit]
    ,SoftwareLicenseUseRightIBM.PVULimitApplies AS [PVULimitApplies]
    ,SoftwareLicense.EndOfLifeRecipient AS [EndOfLifeRecipient]
    ,CAST(SoftwareLicense.ResalePrice * ResalePriceRate.Rate AS money) AS [ResalePrice]
    ,SoftwareLicense.RequestNo AS [RequestNumber]
    ,SoftwareLicense.RetirementDate AS [RetirementDate]
    ,CAST(CAST(SoftwareLicense.ResourceUnitsConsumed AS DECIMAL(38, 5)) AS NVARCHAR) AS [ResourceUnitsConsumed]
    ,SAPSoftwareLicense.SAPServerName AS [SAPServerName]
    ,SAPSoftwareLicenseTypeI18N_BASE.DescriptionDefaultValue AS [SAPBaseType]
    ,EndOfLifeReason.ResourceName AS [EndOfLifeReason]
    ,SAPSoftwareLicenseTypeI18N_SURCHARGE.DescriptionDefaultValue AS [SAPSurcharge]
    ,SAPSoftwareLicenseTypeI18N_SPECIALVERSION.DescriptionDefaultValue AS [SAPSpecialVersion]
    ,SoftwareLicense.SecondUsageWorkLaptop AS [SecondUsageWorkLaptop]
    ,SoftwareLicense.SerialNumber AS [SerialNumber]
    ,SoftwareLicense.TrueUp AS [LicenseSubjectToTrueUp]
    ,TargetOperatingSystemTypeI18N.DefaultValue AS [TargetOperatingSystemType]
    ,SoftwareLicense.SoftwareLicenseTierCode AS [SoftwareLicenseTierCode]
    ,SoftwareLicenseUseRight.ThirdPartyAccessAllowed AS [ThirdPartyAccessAllowed]
    ,SoftwareLicense.SecondUsageAtHome AS [SecondUsageAtHome]
    ,SoftwareLicenseUseRight.ReassignmentTimeLimitApplies AS [ReassignmentTimeLimitApplies]
    ,UpgradeToVersion.UpgradeToVersion AS [UpgradeToVersion]
    ,UpgradeEnabled.UpgradeEnabled AS [UpgradeEnabled]
    ,UpgradeToVersionName.VersionName AS [UpgradeToVersionName]
    ,UpgradeUntil.UpgradeUntil AS [UpgradeUntil]
    ,UpgradeUntilDate.UpgradeUntilDate AS [UpgradeUntilDate]    
    ,AssetWarrantyTypeI18N.WarrantyTypeDefaultValue AS [LicenseWarrantyType]
    ,SoftwareLicense.WarrantyExpiryDate AS [WarrantyExpiryDate]
    ,SoftwareLicenseTierTypeI18N.TierTypeDefaultValue AS [SoftwareLicenseTierType]
    ,SoftwareLicenseUseRight.NumberOfCoresPerSocket AS [NumberOfCoresPerSocket]
    ,SoftwareLicense.NumberOfComputersAllowedPerUserLicensePoint AS [NumberOfComputersAllowedPerUserLicensePoint]
    ,SoftwareLicense.NumberOfSockets AS [NumberOfSockets]
    ,SoftwareLicense.NumberOfApplicationInstallsAllowedPerLicensePoint AS [NumberOfApplicationInstallsAllowedPerLicensePoint]
    ,SoftwareLicense.MinimumNumberOfLicensesPerVM AS [MinimumNumberOfLicensesPerVM]
    ,SoftwareLicense.Comments AS [Comments]    
  FROM SoftwareLicenseCurrentUserScoped AS SoftwareLicense
    LEFT OUTER JOIN AcquisitionModeI18N ON AcquisitionModeI18N.AcquisitionModeID = SoftwareLicense.AcquisitionModeID
    LEFT OUTER JOIN SoftwareLicenseUseRight ON SoftwareLicenseUseRight.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID
    LEFT OUTER JOIN SoftwareLicenseGroupAllocationTotalsCurrentUser AS GroupAssignedTotals ON GroupAssignedTotals.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID
    LEFT OUTER JOIN Category AS Category ON SoftwareLicense.CategoryID = Category.GroupExID
    LEFT OUTER JOIN GroupEx AS CorporateStructure ON SoftwareLicense.BusinessUnitID = CorporateStructure.GroupExID
    LEFT OUTER JOIN GroupEx AS CostCenter ON SoftwareLicense.CostCenterID = CostCenter.GroupExID
    LEFT OUTER JOIN 
    (
      SELECT 
        slp_inner.SoftwareLicenseID
        ,CAST(MAX(CAST(slp_inner.DowngradeToVersion AS int)) AS bit) AS DowngradeToVersion 
      FROM dbo.SoftwareLicenseProduct AS slp_inner 
      WHERE slp_inner.Supplementary = 0 
      GROUP BY slp_inner.SoftwareLicenseID
    ) AS DowngradeToVersion ON DowngradeToVersion.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID
    LEFT OUTER JOIN 
    (
      SELECT 
        slp_inner.SoftwareLicenseID
        ,CAST(MAX(CAST(slp_inner.DowngradeEnabled AS int)) AS bit) AS DowngradeEnabled 
      FROM dbo.SoftwareLicenseProduct AS slp_inner 
      WHERE slp_inner.Supplementary = 0 
      GROUP BY slp_inner.SoftwareLicenseID
    ) AS DowngradeEnabled ON DowngradeEnabled.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID
    LEFT OUTER JOIN 
    (
      SELECT 
        slp_maxed.SoftwareLicenseID
        ,CASE WHEN slp_maxed.ProductCount = 1 THEN ste.EditionName 
         ELSE 
         (
           SELECT 
             ResourceValue 
           FROM dbo.GetTranslation('SoftwareLicenseProduct.Multiple')
         ) END AS EditionName 
      FROM
      (
        SELECT 
          slp_inner.SoftwareLicenseID
          ,MAX(slp_inner.DowngradeToEditionID) AS DowngradeToEditionID
          ,COUNT(slp_inner.SoftwaretitleProductID) AS ProductCount 
        FROM dbo.SoftwareLicenseProduct AS slp_inner 
        WHERE slp_inner.Supplementary = 0 
        GROUP BY slp_inner.SoftwareLicenseID
      ) AS slp_maxed 
      INNER JOIN dbo.SoftwareTitleEdition AS ste ON ste.SoftwareTitleEditionID = slp_maxed.DowngradeToEditionID
     ) AS DowngradeToEditionName ON DowngradeToEditionName.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID
    LEFT OUTER JOIN 
    (
      SELECT 
        slp_maxed.SoftwareLicenseID
        ,CASE WHEN slp_maxed.ProductCount = 1 THEN stv.VersionName 
         ELSE 
         (
           SELECT ResourceValue 
           FROM dbo.GetTranslation('SoftwareLicenseProduct.Multiple')
         ) 
         END AS VersionName 
      FROM 
      (
        SELECT 
          slp_inner.SoftwareLicenseID
          ,MAX(slp_inner.DowngradeToVersionID) AS DowngradeToVersionID
          ,COUNT(slp_inner.SoftwaretitleProductID) AS ProductCount 
        FROM dbo.SoftwareLicenseProduct AS slp_inner 
        WHERE slp_inner.Supplementary = 0 
        GROUP BY slp_inner.SoftwareLicenseID
      ) AS slp_maxed 
      INNER JOIN dbo.SoftwareTitleVersion AS stv ON stv.SoftwareTitleVersionID = slp_maxed.DowngradeToVersionID
    ) AS DowngradeToVersionName ON DowngradeToVersionName.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID
    LEFT OUTER JOIN SoftwareLicenseDurationI18N ON SoftwareLicenseDurationI18N.SoftwareLicenseDurationID = SoftwareLicense.DurationID
    INNER JOIN SoftwareLicenseSummary as sls on sls.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID
    LEFT OUTER JOIN SoftwareLicensePODetailMaintenanceTotalsCurrentUser AS smt ON smt.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID
    LEFT OUTER JOIN SoftwareLicenseComplianceStatusI18N ON SoftwareLicenseComplianceStatusI18N.SoftwareLicenseComplianceStatusID = SoftwareLicense.SoftwareLicenseComplianceStatusID
    LEFT OUTER JOIN
    (
      SELECT 
        slp_inner.SoftwareLicenseID
        ,CAST(MAX(CAST(slp_inner.DowngradeToEdition AS int)) AS bit) AS DowngradeToEdition 
      FROM dbo.SoftwareLicenseProduct AS slp_inner WHERE slp_inner.Supplementary = 0 
      GROUP BY slp_inner.SoftwareLicenseID
    ) DowngradeToEdition ON DowngradeToEdition.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID
    LEFT OUTER JOIN dbo.SoftwareLicenseKeyTypeI18N ON SoftwareLicenseKeyTypeI18N.SoftwareLicenseKeyTypeID = SoftwareLicense.LicenseKeyTypeID
    LEFT OUTER JOIN SoftwareLicenseMetricI18N ON SoftwareLicenseMetricI18N.SoftwareLicenseMetricID = SoftwareLicense.SoftwareLicenseMetricID
    LEFT OUTER JOIN SoftwareLicenseTypeI18N ON SoftwareLicenseTypeI18N.SoftwareLicenseTypeID = SoftwareLicense.LicenseTypeID
    LEFT OUTER JOIN GroupEx AS Location ON SoftwareLicense.LocationID = Location.GroupExID
    LEFT OUTER JOIN ComplianceUser ON ComplianceUser.ComplianceUserID = SoftwareLicense.ManagerID
    LEFT JOIN SoftwareLicensePricePerRightInfo AS PricePerRight ON SoftwareLicense.SoftwareLicenseID = PricePerRight.SoftwareLicenseID
    LEFT JOIN SoftwareLicensePricePerRightInfo AS PricePerRightPeriodType ON SoftwareLicense.SoftwareLicenseID = PricePerRightPeriodType.SoftwareLicenseID LEFT OUTER JOIN dbo.PeriodTypeI18N AS PricePerRightPeriodTypeI18N ON PricePerRightPeriodTypeI18N.PeriodTypeID = PricePerRightPeriodType.PricePerRightInDefaultCurrencyPeriodTypeID
    LEFT OUTER JOIN SoftwareLicenseTypePriority AS sltp ON sltp.SoftwareLicenseTypeID = SoftwareLicense.LicenseTypeID
    LEFT OUTER JOIN Vendor AS Publisher ON Publisher.VendorID = SoftwareLicense.PublisherID
    LEFT OUTER JOIN 
    (
      SELECT 
        slp_maxed.SoftwareLicenseID
        ,CASE WHEN slp_maxed.ProductCount = 1 THEN stp.ProductName 
         ELSE 
         (
           SELECT ResourceValue 
           FROM dbo.GetTranslation('SoftwareLicenseProduct.Multiple')
         ) 
         END AS ProductName 
      FROM 
      (
        SELECT 
          slp_inner.SoftwareLicenseID, 
          MIN(slp_inner.SoftwareTitleProductID) AS SoftwareTitleProductID, 
          COUNT(slp_inner.SoftwaretitleProductID) AS ProductCount 
        FROM dbo.SoftwareLicenseProduct AS slp_inner 
        WHERE slp_inner.Supplementary = 0 
        GROUP BY slp_inner.SoftwareLicenseID
      ) AS slp_maxed 
      INNER JOIN dbo.SoftwareTitleProduct AS stp ON stp.SoftwareTitleProductID = slp_maxed.SoftwareTitleProductID
    ) AS ProductPrimary ON ProductPrimary.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID
    LEFT OUTER JOIN GetCurrencyExchangeRates(@CurrencyID) AS PurchasePriceRate ON PurchasePriceRate.CurrencyRateID = SoftwareLicense.PurchasePriceRateID
    LEFT OUTER JOIN SoftwareLicenseUseRightIBM ON SoftwareLicenseUseRightIBM.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID
    LEFT OUTER JOIN GetCurrencyExchangeRates(@CurrencyID) AS ResalePriceRate ON ResalePriceRate.CurrencyRateID = SoftwareLicense.ResalePriceRateID
    LEFT OUTER JOIN dbo.SAPSoftwareLicense ON SAPSoftwareLicense.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID
    LEFT OUTER JOIN dbo.SAPSoftwareLicenseTypeI18N AS SAPSoftwareLicenseTypeI18N_BASE ON SAPSoftwareLicenseTypeI18N_BASE.SAPSoftwareLicenseTypeID = SAPSoftwareLicense.SAPBaseLicenseTypeID
    LEFT OUTER JOIN EndOfLifeReason ON EndOfLifeReason.EndOfLifeReasonID = SoftwareLicense.EndOfLifeReasonID
    LEFT OUTER JOIN dbo.SAPSoftwareLicenseTypeI18N AS SAPSoftwareLicenseTypeI18N_SURCHARGE ON SAPSoftwareLicenseTypeI18N_SURCHARGE.SAPSoftwareLicenseTypeID = SAPSoftwareLicense.SAPSurchargeID
    LEFT OUTER JOIN dbo.SAPSoftwareLicenseTypeI18N AS SAPSoftwareLicenseTypeI18N_SPECIALVERSION ON SAPSoftwareLicenseTypeI18N_SPECIALVERSION.SAPSoftwareLicenseTypeID = SAPSoftwareLicense.SAPSpecialVersionID
    LEFT OUTER JOIN LicenseStatusI18N ON LicenseStatusI18N.LicenseStatusID = SoftwareLicense.LicenseStatusID
    LEFT OUTER JOIN SoftwareLicenseUseRight AS slurtost ON slurtost.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID 
    LEFT OUTER JOIN TargetOperatingSystemTypeI18N ON TargetOperatingSystemTypeI18N.TargetOperatingSystemTypeID = slurtost.TargetOperatingSystemTypeID
    LEFT OUTER JOIN 
    (
      SELECT 
        slp_inner.SoftwareLicenseID
        ,CAST(MAX(CAST(slp_inner.UpgradeToVersion AS int)) AS bit) AS UpgradeToVersion 
      FROM dbo.SoftwareLicenseProduct AS slp_inner 
      WHERE slp_inner.Supplementary = 0 
      GROUP BY slp_inner.SoftwareLicenseID
    ) AS UpgradeToVersion ON UpgradeToVersion.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID
    LEFT OUTER JOIN 
    (
      SELECT 
        slp_inner.SoftwareLicenseID
        ,CAST(MAX(CAST(slp_inner.UpgradeEnabled AS int)) AS bit) AS UpgradeEnabled 
      FROM dbo.SoftwareLicenseProduct AS slp_inner WHERE slp_inner.Supplementary = 0 
      GROUP BY slp_inner.SoftwareLicenseID
    ) AS UpgradeEnabled ON UpgradeEnabled.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID
    LEFT OUTER JOIN 
    (
      SELECT 
        slp_maxed.SoftwareLicenseID
        ,CASE WHEN slp_maxed.ProductCount = 1 THEN stv.VersionName 
        ELSE 
        (
          SELECT ResourceValue 
          FROM dbo.GetTranslation('SoftwareLicenseProduct.Multiple')
        ) END AS VersionName 
      FROM 
      (
        SELECT 
          slp_inner.SoftwareLicenseID
          ,MAX(slp_inner.UpgradeToVersionID) AS UpgradeToVersionID
          ,COUNT(slp_inner.SoftwaretitleProductID) AS ProductCount 
        FROM dbo.SoftwareLicenseProduct AS slp_inner 
        WHERE slp_inner.Supplementary = 0 
        GROUP BY slp_inner.SoftwareLicenseID
      ) AS slp_maxed 
      INNER JOIN dbo.SoftwareTitleVersion AS stv ON stv.SoftwareTitleVersionID = slp_maxed.UpgradeToVersionID
    ) AS UpgradeToVersionName ON UpgradeToVersionName.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID
    LEFT OUTER JOIN 
    (
      SELECT 
        slp_inner.SoftwareLicenseID
        ,CAST(MAX(CAST(slp_inner.UpgradeUntil AS int)) AS bit) AS UpgradeUntil 
      FROM dbo.SoftwareLicenseProduct AS slp_inner WHERE slp_inner.Supplementary = 0 
      GROUP BY slp_inner.SoftwareLicenseID
    ) AS UpgradeUntil ON UpgradeUntil.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID
    LEFT OUTER JOIN 
    (
      SELECT 
        slp_inner.SoftwareLicenseID
        ,MAX(slp_inner.UpgradeUntilDate) AS UpgradeUntilDate 
      FROM dbo.SoftwareLicenseProduct AS slp_inner 
      WHERE slp_inner.Supplementary = 0 
      GROUP BY slp_inner.SoftwareLicenseID
    ) AS UpgradeUntilDate ON UpgradeUntilDate.SoftwareLicenseID = SoftwareLicense.SoftwareLicenseID
    LEFT OUTER JOIN Vendor ON Vendor.VendorID = SoftwareLicense.VendorID
    LEFT OUTER JOIN AssetWarrantyTypeI18N ON AssetWarrantyTypeI18N.AssetWarrantyTypeID = SoftwareLicense.WarrantyTypeID
    LEFT OUTER JOIN dbo.SoftwareLicenseTierTypeI18N ON SoftwareLicenseTierTypeI18N.SoftwareLicenseTierTypeID = SoftwareLicense.SoftwareLicenseTierTypeID
  )
SELECT *
FROM LicenseInfo as sli
ORDER BY sli.Name, sli.Edition, sli.Version
  
    