---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export AssetLease
-- Export Number: 1.03
-- Updated: 09/09/2023 12:15
---------------------------------------------------------------------------

--USE FNMSCompliance

SELECT	
	a.[AssetID],
  --a.[ParentAssetID],
	a.[ShortDescription] as [AssetName],
	ast.[AssetTypeName] as [AssetType],
  --a.[LocationID],
	--l.[Path] AS [Location],
  --a.[BusinessUnitID],
	--d.[Path] AS [BusinessUnit],  
  --a.[CostCenterID],
	--cc.[Path] AS [CostCenter],  
  --a.[CategoryID],
	--cat.[Path] AS [Category],
	--a.[Manufacturer] as [ManufacturerName],
	--a.[ManufacturerPartNo],
	--a.[ModelNo],
	--a.[SerialNumber] as [SerialNo],
	--c.[OperatingSystem],
	--c.[ServicePack],
	--cct.[DefaultValue] as [ChassisType],
	--c.[NumberOfProcessors],
	--c.[TotalMemory],
	--c.[TotalDiskSpace],
	--case 
	--  when c.[ComplianceComputerStatusID] <> 4 then convert(bit], 1) 
	--  else
	--	  convert(bit], 0)
	--end as [LinkedToComputer],
	--md.[IMEI],
	--md.[PhoneNo],
	--md.[EmailAddress]
  --a.[AssetTypeID],
	a.[AssetTag],
  --a.[AssetStatusID],
	--st.[StatusResourceName],
	--st.[StatusDefaultValue] as [AssetStatus],
  --a.[AssignToUserID],
	--cu.[UserName] AS [AssignedUser],
	--cd.[QualifiedName] AS [UserDomain],
  --a.[RequestNo],
  --a.[PartNo],  
  --a.[AcquisitionModeID],
  --a.[PrimaryPurchaseOrderNo],
  --a.[PrimaryPurchaseOrderDate],
	--a.[PurchasePrice],    
	--a.[PurchasePriceRateID],
  a.[VendorID],
	--a.[AssetWarrantyTypeID],
	--awt.[WarrantyTypeResourceName],
	--awt.[WarrantyTypeDefaultValue] as [WarrantyType],
	--a.[WarrantyExpirationDate] as [WarrantyEndDate],
	--a.[DeliveryDate],
	--a.[InstallationDate],
	--a.[RetirementDate],
	--a.[DisposalDate],
	--a.[DeletionDate],
	--a.[InventoryDate],
  --a.[InventoryAgent],
  --a.[InventoryDateManual],
  --a.[InventoryAgentManual],
  a.[IsLeased],
  a.[LeaseNo],
  a.[LeaseName],
  a.[LeaseStartDate],
  a.[LeaseEndDate],
  a.[LeaseTerminationDate],
  a.[LeaseEndReasonID],
  a.[LeasePrice],
  a.[LeasePriceRateID],
  a.[LeasePeriodicPayment],
  a.[LeasePeriodicPaymentRateID],
  a.[LeasePeriodTypeID],
  a.[LeaseBuyoutCost],
  a.[LeaseBuyoutCostRateID],
  a.[LeaseComments]
  --a.[ChargeBackPrice],
  --a.[ChargeBackPriceRateID],
  --a.[ChargeBackPeriodTypeID],
  --a.[DepreciationCurrentValue],
  --a.[DepreciationCurrentValueRateID],
  --a.[DepreciationResidualValue],
  --a.[DepreciationResidualValueRateID],
  --a.[DepreciationMethodID],
  --a.[DepreciationPeriod],
  --a.[DepreciationRate],
  --a.[WrittenOffValue],
  --a.[WrittenOffValueRateID],
  --a.[EndOfLifeRecipient],
  --a.[EndOfLifeReasonID],
  --a.[ResalePrice],
  --a.[ResalePriceRateID],
  --a.[CreationUser],
  --a.[CreationDate],
  --a.[UpdatedUser],
  --a.[UpdatedDate],
	--a.[Comments]
FROM dbo.[Asset] AS a
	LEFT OUTER JOIN dbo.[AssetTypeI18N] AS ast on a.[AssetTypeID] = ast.[AssetTypeID]
	LEFT OUTER JOIN dbo.[AssetStatusI18N] AS st on a.[AssetStatusID] = st.[AssetStatusID]
	LEFT OUTER JOIN dbo.[AssetWarrantyTypeI18N] AS awt on a.[AssetWarrantyTypeID] = awt.[AssetWarrantyTypeID]
	LEFT OUTER JOIN dbo.[ComplianceComputer] c on c.[AssetID] = a.[AssetID]
	LEFT OUTER JOIN dbo.[MobileDevice] AS md ON md.[ComplianceComputerID] = c.[ComplianceComputerID]
	LEFT OUTER JOIN dbo.[Location] AS l ON l.[GroupExID] = a.[LocationID]
	LEFT OUTER JOIN dbo.[CorporateUnit] AS d ON d.[GroupExID] = a.[BusinessUnitID]
	LEFT OUTER JOIN dbo.[CostCenter] AS cc ON cc.[GroupExID] = a.[CostCenterID]
	LEFT OUTER JOIN dbo.[Category] AS cat ON cat.[GroupExID] = a.[CategoryID]
	LEFT OUTER JOIN dbo.[ComplianceUser] AS cu ON cu.[ComplianceUserID] = a.[AssignToUserID]
	LEFT OUTER JOIN dbo.[ComplianceDomain] AS cd ON cd.[ComplianceDomainID] = cu.[ComplianceDomainID]
	LEFT OUTER JOIN dbo.[ComputerChassisTypeI18N] AS cct ON cct.[ChassisTypeID] = c.[ChassisTypeID]
