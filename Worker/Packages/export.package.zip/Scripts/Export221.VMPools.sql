---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export VM Pool records
-- Export Number: 2.31
-- Updated: 12/09/2023 14:15
---------------------------------------------------------------------------

--USE FNMSCompliance

WITH VMPoolInfo AS
(
  SELECT
    ip.PoolName
    ,ip.VCObjectID
    ,ip.ParentName
    ,ip.PoolFriendlyName
    ,ip.HostComputerID
    ,ip.ObjectType
    ,ip.ComplianceConnectionID
    ,ip.ParentObjectType
    ,ip.NumberOfProcessors
    ,ip.NumberOfCores
    ,ip.NumberOfLogicalProcessors
    ,ip.MaxNumberOfLogicalProcessors
  FROM dbo.[ImportedVMPool_MT] as ip

)
SELECT
  vmp.PoolName
  ,vmp.ParentName
  ,vmp.PoolFriendlyName
  ,vmp.HostComputerID
  ,vmp.ObjectType
  ,vmp.ParentObjectType
  ,vmp.NumberOfProcessors
  ,vmp.NumberOfCores
FROM VMPoolInfo as vmp

