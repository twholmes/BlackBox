---------------------------------------------------------------------------
-- Copyright (C) 2023-2024 Crayon Australia
-- This script runs an FNMS data export procedure
-- Export Name: Export Compliance Computers
-- Export Number: 2.02
-- Updated: 12/09/2023 14:15
---------------------------------------------------------------------------

--USE FNMSCompliance

WITH ComputerInfo AS
(
  SELECT  
    cc.ComplianceComputerID,
    cc.ComplianceComputerTypeID,
    cct.DefaultValue as ComplianceComputerTypeName,
    cc.ComputerName,
    cc.ComplianceDomainID,
    FlatDomainName = ISNULL(cdc.FlatName, cdu.FlatName),    
    DomainName = ISNULL(cdc.QualifiedName, cdu.QualifiedName),
    cc.ComplianceComputerStatusID,
    cc.AssetID,
    cc.OperatingSystem,
    cc.ServicePack,
    cc.NumberOfProcessors,
    cc.NumberOfCores,
    cc.NumberOfSockets,
    cc.NumberOfLogicalProcessors,
    cc.PartialNumberOfProcessors,    
    cc.ProcessorType,
    cc.MaxClockSpeed,
    cc.TotalMemory,
    ccht.DefaultValue as ChassisType,
    cc.NumberOfHardDrives,
    cc.TotalDiskSpace,
    cc.NumberOfNetworkCards,
    cc.NumberOfDisplayAdapters,
    cc.IPAddress,
    cc.MACAddress,
    cc.Manufacturer,
    cc.ModelNo,
    cc.SerialNo,
    cc.[UUID],
    v.[UUID] as [VirtualMachineUUID],    
    cc.LocationID,
    cc.BusinessUnitID,
    cc.CostCenterID,
    cc.CategoryID,
    cc.InventoryDate,
    cc.InventoryAgent,
    cc.AssignedUserID,
    cc.CalculatedUserID,
    cc.UpdatedUser,
    cc.UpdatedDate,
    cc.CreationUser,
    cc.CreationDate,
    cc.AssetComplianceStatusID,
    cc.HostIdentifyingNumber,
    vmes.DefaultValue as [VMEnabledState],
    v.AffinityEnabled,
    v.CPUAffinity,
    v.CoreAffinity,
    v.VMLocation,
    vmt.DefaultValue as [VMType],
    vmpt.[DefaultValue] as [PoolType],
    vmp.[PoolName],
    md.IMEI,
    md.PhoneNo,
    md.EmailAddress,
    ast.AssetTypeName,
    a.AssetTag,
    st.StatusResourceName,
    st.StatusDefaultValue,
    a.Comments,
    a.DeliveryDate,
    a.DisposalDate,
    a.InstallationDate,
    a.PurchasePrice,
    a.RequestNo,
    a.RetirementDate,
    awt.WarrantyTypeResourceName,
    awt.WarrantyTypeDefaultValue,
    a.WarrantyExpirationDate,
    a.ShortDescription,
    a.LeaseEndDate,
    -- Irrelevant in this context
    NULL AS PreExpiryDate,
    a.ManufacturerPartNo,
    CASE WHEN a.AssetID IS NULL THEN cccu.UserName ELSE acu.UserName END AS AssignedUser,
    ExternalComputers.LinkedToComputer,
    cat.Path AS Category,
    a.SerialNumber,
    a.PurchasePriceRateID,
    a.AssetWarrantyTypeID,
    a.DeletionDate,
    cdu.QualifiedName AS UserDomain,
    a.IsLeased,
    l.Path AS Location,
    d.Path AS Department,
    costc.Path AS CostCenter
    -- 
  FROM dbo.ComplianceComputer cc WITH (NOLOCK)
    LEFT OUTER JOIN dbo.ComplianceComputerInventorySourceType i WITH (NOLOCK) ON i.ComplianceComputerInventorySourceTypeID = cc.ComplianceComputerInventorySourceTypeID
    LEFT OUTER JOIN dbo.ComplianceComputerType cct WITH (NOLOCK) ON cct.ComplianceComputerTypeID = cc.ComplianceComputerTypeID
    LEFT OUTER JOIN dbo.ComputerChassisTypeI18N AS ccht WITH (NOLOCK) ON ccht.ChassisTypeID = cc.ChassisTypeID
    LEFT OUTER JOIN dbo.ComputerChassisTypeI18N AS accht WITH (NOLOCK) ON accht.ChassisTypeID = cc.AssignedChassisTypeID
    LEFT OUTER JOIN dbo.ComplianceTranslation ctt WITH (NOLOCK) ON ctt.ResourceString = cct.ResourceName
    LEFT OUTER JOIN dbo.ComplianceTranslation cti WITH (NOLOCK) ON cti.ResourceString = i.ResourceName
    LEFT OUTER JOIN dbo.VirtualMachine v WITH (NOLOCK) ON v.ComplianceComputerID = cc.ComplianceComputerID AND v.VMSourceTypeID != 1 -- 'VMSourceType.Manual'
    LEFT OUTER JOIN dbo.[VMTypeI18N] as vmt ON vmt.[VMTypeID] = v.[VMTypeID]
    LEFT OUTER JOIN dbo.[VMEnabledStateI18N] AS vmes ON vmes.[VMEnabledStateID] = v.[VMEnabledStateID]
    LEFT OUTER JOIN dbo.[VMPool] as vmp ON vmp.[VMPoolID] = v.[VMPoolID]
    LEFT OUTER JOIN dbo.[VMPoolTypeI18N] AS vmpt ON vmpt.[VMPoolTypeID] = vmp.[VMPoolTypeID]
  --FROM dbo.ComplianceComputerI18n AS cc WITH (NOLOCK)
    LEFT OUTER JOIN dbo.Asset AS a WITH (NOLOCK) ON cc.AssetID = a.AssetID
    LEFT OUTER JOIN dbo.AssetTypeI18N AS ast on a.AssetTypeID = ast.AssetTypeID
    LEFT OUTER JOIN dbo.AssetStatusI18N AS st on a.AssetStatusID = st.AssetStatusID
    LEFT OUTER JOIN dbo.AssetWarrantyTypeI18N AS awt on a.AssetWarrantyTypeID = awt.AssetWarrantyTypeID
    LEFT OUTER JOIN dbo.ComplianceUser AS acu WITH (NOLOCK) ON acu.ComplianceUserID = a.AssignToUserID
    LEFT OUTER JOIN dbo.ComplianceUser AS cccu WITH (NOLOCK) ON cccu.ComplianceUserID = cc.AssignedUserID
    LEFT OUTER JOIN dbo.Category AS cat ON cat.GroupExID = a.CategoryID
    LEFT OUTER JOIN dbo.Location AS l ON l.GroupExID = a.LocationID
    LEFT OUTER JOIN dbo.CorporateUnit AS d ON d.GroupExID = a.BusinessUnitID
    LEFT OUTER JOIN dbo.CostCenter AS costc ON costc.GroupExID = a.CostCenterID
    LEFT OUTER JOIN dbo.ComplianceDomain AS cdu ON cdu.ComplianceDomainID = cccu.ComplianceDomainID
    LEFT OUTER JOIN dbo.ComplianceDomain AS cdc ON cdc.ComplianceDomainID = cc.ComplianceDomainID
    LEFT OUTER JOIN dbo.MobileDevice md ON md.ComplianceComputerID = cc.ComplianceComputerID
    LEFT OUTER JOIN
    (
      SELECT ComplianceComputerID,
        CASE 
          WHEN ComplianceComputerStatusID <> 4 THEN CONVERT(BIT, 1) 
          ELSE CONVERT(BIT, 0)
          END AS LinkedToComputer
      FROM dbo.ComplianceComputer WITH (NOLOCK)
    ) AS ExternalComputers ON ExternalComputers.ComplianceComputerID = cc.ComplianceComputerID
  WHERE a.AssetID IN (SELECT * FROM TableAssetCurrentUser_WithVMs(NULL, NULL, NULL, NULL))
)
SELECT
  ci.[ComplianceComputerID] as [ComputerID],
  ci.[ComputerName],
  ci.[FlatDomainName] as [DomainFlatName],
  ci.[DomainName] as [DomainQualifiedName],
  ci.[UUID] as [BIOSUUID],
  ci.[OperatingSystem],
  ci.[ServicePack],
  ci.[EmailAddress],
  ci.[PhoneNo] as [PhoneNumber],
  ci.[Manufacturer],
  ci.[ModelNo],
  ci.[SerialNo],
  ci.[ChassisType],
  ci.[TotalMemory],
  ci.[NumberOfDisplayAdapters],
  ci.[VirtualMachineUUID],
  ci.[IMEI],
  ci.[NumberOfProcessors],
  ci.[ProcessorType],
  ci.[MaxClockSpeed],
  ci.[NumberOfCores],
  ci.[NumberOfSockets],
  ci.[NumberOfLogicalProcessors],
  ci.[PartialNumberOfProcessors],
  ci.[NumberOfHardDrives],
  ci.[TotalDiskSpace],
  ci.[NumberOfNetworkCards],
  ci.[IPAddress],
  ci.[MACAddress],
  '' as [LastLoggedOnUser],
  '' as [LastLogonDate],
  '' as [CalculatedUser],
  '' as [HostComputerID],
  ci.[VMType] as [VirtualMachineType],
  ci.[VMEnabledState],
  ci.[AffinityEnabled],
  ci.[CPUAffinity],
  ci.[CoreAffinity],
  ci.[ComplianceComputerTypeName] as [ComplianceComputerType],
  ci.[HostIdentifyingNumber],
  '' as [HostType],
  ci.[VMLocation],
  ci.[PoolName],
  ci.[PoolType],
  '' as [CPUUsage],
  '' as [MemoryUsage],
  ci.[InventoryDate],
  '' as [ClusterID],
  '' as [ClusterNodeType],
  ci.[HostIdentifyingNumber] as [HostID],
  '' as [FirmwareSerialNumber],
  '' as [MachineID],
  '' as [InstanceCloudID],
  '' as [CloudServiceProvider],
  '' as [InstanceAffinity],
  '' as [ImageID],
  '' as [LaunchTime],
  '' as [NetworkID],
  '' as [LifecycleMode],
  '' as [Account],
  '' as [ThreadsPerCore],
  '' as [InstanceType],
  '' as [Region],
  '' as [AvailabilityZone],
  '' as [InstanceTenancy]
FROM ComputerInfo as ci
